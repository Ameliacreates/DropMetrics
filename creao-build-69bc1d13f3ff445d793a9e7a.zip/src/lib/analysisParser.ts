/**
 * Parser utilities to convert raw analysis text into simplified data bubbles
 */

export interface DataBubble {
	icon: string;
	title: string;
	value: string;
	description: string;
	color: string;
}

/**
 * Parse demand analysis into simplified data bubbles
 */
export function parseDemandAnalysis(rawText: string): DataBubble[] {
	const bubbles: DataBubble[] = [];

	// Extract search volume
	const volumeMatch = rawText.match(/(\d{1,3}(?:,\d{3})*|\d+)\s*(?:monthly\s*)?searches/i);
	if (volumeMatch) {
		bubbles.push({
			icon: "📊",
			title: "Search Volume",
			value: volumeMatch[1] + " searches/mo",
			description: "Monthly search interest",
			color: "blue",
		});
	}

	// Extract trend
	const trendMatches = rawText.match(/(growing|increasing|rising|upward|declining|decreasing|stable|steady)/gi);
	if (trendMatches && trendMatches.length > 0) {
		const trend = trendMatches[0].toLowerCase();
		const isPositive = ["growing", "increasing", "rising", "upward"].includes(trend);
		bubbles.push({
			icon: isPositive ? "📈" : trend === "stable" ? "➡️" : "📉",
			title: "Market Trend",
			value: trend.charAt(0).toUpperCase() + trend.slice(1),
			description: isPositive ? "Strong growth momentum" : trend === "stable" ? "Consistent demand" : "Declining interest",
			color: isPositive ? "green" : trend === "stable" ? "yellow" : "red",
		});
	}

	// Extract market size
	const sizeMatch = rawText.match(/\$(\d+(?:\.\d+)?)\s*([BM])/i);
	if (sizeMatch) {
		const size = sizeMatch[1];
		const unit = sizeMatch[2] === "B" ? "Billion" : "Million";
		bubbles.push({
			icon: "💰",
			title: "Market Size",
			value: `$${size}${sizeMatch[2]}`,
			description: `${size} ${unit} market`,
			color: "purple",
		});
	}

	// Extract seasonal pattern
	const seasonMatch = rawText.match(/(Q[1-4]|November|December|January|February|March|April|May|June|July|August|September|October|Holiday|Summer|Winter|Spring|Fall)/i);
	if (seasonMatch) {
		bubbles.push({
			icon: "📅",
			title: "Peak Season",
			value: seasonMatch[0],
			description: "Best selling period",
			color: "orange",
		});
	}

	// Extract growth rate (CAGR)
	const cagrMatch = rawText.match(/(\d+(?:\.\d+)?)\s*%.*?(CAGR|growth|annually)/i);
	if (cagrMatch) {
		bubbles.push({
			icon: "🚀",
			title: "Growth Rate",
			value: cagrMatch[1] + "% yearly",
			description: "Annual growth projection",
			color: "green",
		});
	}

	return bubbles;
}

/**
 * Parse competition analysis into simplified data bubbles
 */
export function parseCompetitionAnalysis(rawText: string): DataBubble[] {
	const bubbles: DataBubble[] = [];

	// Extract pricing range
	const priceMatch = rawText.match(/\$(\d+).*?\$(\d+)/);
	if (priceMatch) {
		bubbles.push({
			icon: "💵",
			title: "Price Range",
			value: `$${priceMatch[1]} - $${priceMatch[2]}`,
			description: "Competitor pricing",
			color: "blue",
		});
	}

	// Extract average price
	const avgMatch = rawText.match(/average.*?\$(\d+)/i) || rawText.match(/\$(\d+).*?average/i);
	if (avgMatch) {
		bubbles.push({
			icon: "📊",
			title: "Average Price",
			value: `$${avgMatch[1]}`,
			description: "Market average",
			color: "purple",
		});
	}

	// Extract saturation level
	const saturationMatch = rawText.match(/(Low|Medium|High|Oversaturated)/i);
	if (saturationMatch) {
		const level = saturationMatch[0];
		const isGood = level.toLowerCase() === "low" || level.toLowerCase() === "medium";
		bubbles.push({
			icon: isGood ? "✅" : "⚠️",
			title: "Competition Level",
			value: level,
			description: isGood ? "Good opportunity" : "Crowded market",
			color: isGood ? "green" : level.toLowerCase() === "high" ? "orange" : "red",
		});
	}

	// Extract market share info
	const shareMatch = rawText.match(/(\d+)\s*%\s*market\s*share/i);
	if (shareMatch) {
		bubbles.push({
			icon: "🎯",
			title: "Top Competitor",
			value: shareMatch[1] + "% share",
			description: "Leading market player",
			color: "orange",
		});
	}

	// Extract competitive advantage keywords
	const advantages = ["differentiation", "unique", "branding", "quality", "service"];
	for (const adv of advantages) {
		if (rawText.toLowerCase().includes(adv)) {
			bubbles.push({
				icon: "💡",
				title: "Key Strategy",
				value: adv.charAt(0).toUpperCase() + adv.slice(1),
				description: "Competitive edge",
				color: "yellow",
			});
			break;
		}
	}

	return bubbles;
}

/**
 * Parse business plan sections into simplified data bubbles
 */
export function parseBusinessPlan(section: string, sectionType: "executive" | "market" | "financial" | "operational"): DataBubble[] {
	const bubbles: DataBubble[] = [];

	if (sectionType === "executive") {
		// Extract target demographic
		const ageMatch = section.match(/(\d+)-(\d+)\s*years/i);
		if (ageMatch) {
			bubbles.push({
				icon: "👥",
				title: "Target Audience",
				value: `${ageMatch[1]}-${ageMatch[2]} years old`,
				description: "Primary demographic",
				color: "blue",
			});
		}

		// Extract value proposition keywords
		if (section.toLowerCase().includes("premium") || section.toLowerCase().includes("quality")) {
			bubbles.push({
				icon: "⭐",
				title: "Positioning",
				value: "Premium Quality",
				description: "Market positioning",
				color: "purple",
			});
		}
	}

	if (sectionType === "financial") {
		// Extract startup costs
		const startupMatch = section.match(/\$(\d{1,3}(?:,\d{3})*)/);
		if (startupMatch) {
			bubbles.push({
				icon: "💰",
				title: "Startup Cost",
				value: `$${startupMatch[1]}`,
				description: "Initial investment",
				color: "blue",
			});
		}

		// Extract revenue projections
		const revenueMatch = section.match(/\$(\d{1,3}(?:,\d{3})*)-\$(\d{1,3}(?:,\d{3})*)/);
		if (revenueMatch) {
			bubbles.push({
				icon: "📈",
				title: "Revenue Target",
				value: `$${revenueMatch[1]}-$${revenueMatch[2]}`,
				description: "Monthly projection",
				color: "green",
			});
		}

		// Extract profit margin
		const marginMatch = section.match(/(\d+)-(\d+)%/);
		if (marginMatch) {
			bubbles.push({
				icon: "💹",
				title: "Profit Margin",
				value: `${marginMatch[1]}-${marginMatch[2]}%`,
				description: "Expected margins",
				color: "green",
			});
		}

		// Extract break-even
		const breakEvenMatch = section.match(/Month\s*(\d+)/i);
		if (breakEvenMatch) {
			bubbles.push({
				icon: "🎯",
				title: "Break-Even",
				value: `Month ${breakEvenMatch[1]}`,
				description: "Profitability timeline",
				color: "orange",
			});
		}
	}

	if (sectionType === "operational") {
		// Extract marketing channels
		const channels = ["TikTok", "Instagram", "Facebook", "YouTube", "Pinterest"];
		for (const channel of channels) {
			if (section.includes(channel)) {
				bubbles.push({
					icon: "📱",
					title: "Marketing Channel",
					value: channel,
					description: "Primary platform",
					color: "blue",
				});
				break;
			}
		}

		// Extract shipping timeframe
		const shippingMatch = section.match(/(\d+)-(\d+)\s*day/i);
		if (shippingMatch) {
			bubbles.push({
				icon: "🚚",
				title: "Shipping Time",
				value: `${shippingMatch[1]}-${shippingMatch[2]} days`,
				description: "Delivery speed",
				color: "purple",
			});
		}
	}

	return bubbles;
}

/**
 * Parse complete business plan into simplified data bubbles
 */
export function parseBusinessPlanComplete(fullText: string): DataBubble[] {
	const bubbles: DataBubble[] = [];

	// Extract startup costs
	const startupMatch = fullText.match(/\$(\d{1,3}(?:,\d{3})*)/);
	if (startupMatch) {
		bubbles.push({
			icon: "💰",
			title: "Startup Cost",
			value: `$${startupMatch[1]}`,
			description: "Initial investment needed",
			color: "blue",
		});
	}

	// Extract revenue projections
	const revenueMatch = fullText.match(/\$(\d{1,3}(?:,\d{3})*)-\$(\d{1,3}(?:,\d{3})*)/);
	if (revenueMatch) {
		bubbles.push({
			icon: "📈",
			title: "Revenue Target",
			value: `$${revenueMatch[1]}-$${revenueMatch[2]}`,
			description: "Monthly revenue goal",
			color: "green",
		});
	}

	// Extract profit margin
	const marginMatch = fullText.match(/(\d+)-(\d+)%/);
	if (marginMatch) {
		bubbles.push({
			icon: "💹",
			title: "Profit Margin",
			value: `${marginMatch[1]}-${marginMatch[2]}%`,
			description: "Expected profit margins",
			color: "green",
		});
	}

	// Extract target demographic
	const ageMatch = fullText.match(/(\d+)-(\d+)\s*years/i);
	if (ageMatch) {
		bubbles.push({
			icon: "👥",
			title: "Target Audience",
			value: `${ageMatch[1]}-${ageMatch[2]} years`,
			description: "Primary customer age",
			color: "purple",
		});
	}

	// Extract break-even
	const breakEvenMatch = fullText.match(/Month\s*(\d+)/i);
	if (breakEvenMatch) {
		bubbles.push({
			icon: "🎯",
			title: "Break-Even",
			value: `Month ${breakEvenMatch[1]}`,
			description: "Profitability timeline",
			color: "orange",
		});
	}

	// Extract marketing channels
	const channels = ["TikTok", "Instagram", "Facebook", "YouTube", "Pinterest"];
	for (const channel of channels) {
		if (fullText.includes(channel)) {
			bubbles.push({
				icon: "📱",
				title: "Marketing Channel",
				value: channel,
				description: "Primary advertising platform",
				color: "blue",
			});
			break;
		}
	}

	// Extract positioning
	if (fullText.toLowerCase().includes("premium") || fullText.toLowerCase().includes("quality")) {
		bubbles.push({
			icon: "⭐",
			title: "Brand Positioning",
			value: "Premium Quality",
			description: "Market positioning strategy",
			color: "purple",
		});
	}

	// Extract shipping timeframe
	const shippingMatch = fullText.match(/(\d+)-(\d+)\s*day/i);
	if (shippingMatch) {
		bubbles.push({
			icon: "🚚",
			title: "Shipping Time",
			value: `${shippingMatch[1]}-${shippingMatch[2]} days`,
			description: "Expected delivery time",
			color: "yellow",
		});
	}

	return bubbles;
}

/**
 * Get color classes for bubble styling
 */
export function getBubbleColorClasses(color: string): { bg: string; border: string; text: string } {
	const colorMap: Record<string, { bg: string; border: string; text: string }> = {
		blue: {
			bg: "bg-blue-50 dark:bg-blue-950/20",
			border: "border-blue-200 dark:border-blue-900",
			text: "text-blue-700 dark:text-blue-300",
		},
		green: {
			bg: "bg-green-50 dark:bg-green-950/20",
			border: "border-green-200 dark:border-green-900",
			text: "text-green-700 dark:text-green-300",
		},
		purple: {
			bg: "bg-purple-50 dark:bg-purple-950/20",
			border: "border-purple-200 dark:border-purple-900",
			text: "text-purple-700 dark:text-purple-300",
		},
		orange: {
			bg: "bg-orange-50 dark:bg-orange-950/20",
			border: "border-orange-200 dark:border-orange-900",
			text: "text-orange-700 dark:text-orange-300",
		},
		red: {
			bg: "bg-red-50 dark:bg-red-950/20",
			border: "border-red-200 dark:border-red-900",
			text: "text-red-700 dark:text-red-300",
		},
		yellow: {
			bg: "bg-yellow-50 dark:bg-yellow-950/20",
			border: "border-yellow-200 dark:border-yellow-900",
			text: "text-yellow-700 dark:text-yellow-300",
		},
	};

	return colorMap[color] || colorMap.blue;
}
