import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Save, Sparkles, Info, TrendingUp } from "lucide-react";
import { ProductAnalysisORM, ProductAnalysisSaturationLevel } from "@/sdk/database/orm/orm_product_analysis";
import { getUserId } from "@/sdk/core/auth";
import { estimateFees } from "@/lib/analysisService";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useProduct } from "@/contexts/ProductContext";
import { localDB } from "@/lib/localStorageDB";
import { DataSourceIndicator } from "@/components/DataSourceIndicator";
import { fetchRealProductData } from "@/lib/realDataProfitService";

export function ProfitCalculator() {
	const { setSelectedProduct } = useProduct();
	const [productName, setProductName] = useState("");
	const [costPrice, setCostPrice] = useState("");
	const [sellingPrice, setSellingPrice] = useState("");
	const [shippingFees, setShippingFees] = useState("");
	const [platformFees, setPlatformFees] = useState("");
	const [customerAcquisitionCost, setCustomerAcquisitionCost] = useState("");
	const [creditCardFeePercent, setCreditCardFeePercent] = useState("2.9");
	const [isSaving, setIsSaving] = useState(false);
	const [saveMessage, setSaveMessage] = useState("");
	const [autoPredictFees, setAutoPredictFees] = useState(false);
	const [isPredicting, setIsPredicting] = useState(false);
	const [isFetchingRealData, setIsFetchingRealData] = useState(false);
	const [feeExplanations, setFeeExplanations] = useState<{
		shipping: string;
		platform: string;
		cac: string;
		creditCard: string;
		confidence: string;
	} | null>(null);

	const cost = parseFloat(costPrice) || 0;
	const selling = parseFloat(sellingPrice) || 0;
	const shipping = parseFloat(shippingFees) || 0;
	const platform = parseFloat(platformFees) || 0;
	const cac = parseFloat(customerAcquisitionCost) || 0;
	const creditCardFeeRate = parseFloat(creditCardFeePercent) || 0;
	const creditCardFee = (selling * creditCardFeeRate) / 100;

	const totalCost = cost + shipping + platform + cac + creditCardFee;
	const netProfit = selling - totalCost;
	const profitMargin = selling > 0 ? ((netProfit / selling) * 100) : 0;
	const breakEvenUnits = netProfit > 0 ? Math.ceil(totalCost / netProfit) : 0;
	const roi = totalCost > 0 ? ((netProfit / totalCost) * 100) : 0;

	// Auto-predict fees when toggle is enabled and selling price changes
	useEffect(() => {
		const predictFees = async () => {
			if (!autoPredictFees || !selling || selling <= 0) {
				return;
			}

			setIsPredicting(true);
			try {
				const estimate = await estimateFees(selling, productName);
				setShippingFees(estimate.shippingFee.toString());
				setPlatformFees(estimate.platformFee.toString());
				setCustomerAcquisitionCost(estimate.customerAcquisitionCost.toString());
				setCreditCardFeePercent(estimate.creditCardFeePercent.toString());
				setFeeExplanations({
					shipping: estimate.explanation.shipping,
					platform: estimate.explanation.platform,
					cac: estimate.explanation.cac,
					creditCard: estimate.explanation.creditCard,
					confidence: estimate.confidence,
				});
			} catch (error) {
				console.error("Error predicting fees:", error);
			} finally {
				setIsPredicting(false);
			}
		};

		// Debounce the prediction
		const timeoutId = setTimeout(predictFees, 500);
		return () => clearTimeout(timeoutId);
	}, [autoPredictFees, selling, productName]);

	const handleSave = async () => {
		if (!productName.trim()) {
			setSaveMessage("Please enter a product name");
			return;
		}

		setIsSaving(true);
		setSaveMessage("");

		const userId = getUserId() || "anonymous";
		const record = {
			id: "",
			data_creator: "",
			data_updater: "",
			create_time: "",
			update_time: "",
			user_id: userId,
			product_name: productName,
			cost_price: cost,
			selling_price: selling,
			shipping_fees: shipping,
			platform_fees: platform,
			profit_margin: profitMargin,
			break_even_units: breakEvenUnits,
			roi: roi,
			saturation_level: ProductAnalysisSaturationLevel.Unspecified,
		};

		try {
			// Try the remote API first; fall back to localStorage if it fails
			try {
				const orm = ProductAnalysisORM.getInstance();
				await orm.insertProductAnalysis([record]);
			} catch {
				// Remote save failed (no auth token / network) — save locally instead
				localDB.insert([record]);
			}

			// Update the shared product context
			setSelectedProduct({
				productName,
				costPrice: cost,
				sellingPrice: selling,
				shippingCost: shipping,
				marketingCost: platform,
				customerAcquisitionCost: cac,
				creditCardFeePercent: creditCardFeeRate,
			});

			setSaveMessage("Analysis saved successfully!");
			setTimeout(() => setSaveMessage(""), 3000);
		} catch (error) {
			setSaveMessage("Error saving analysis: " + (error instanceof Error ? error.message : "Unknown error"));
		} finally {
			setIsSaving(false);
		}
	};

	const handleFetchRealData = async () => {
		if (!productName.trim()) {
			setSaveMessage("Please enter a product name first");
			return;
		}

		setIsFetchingRealData(true);
		setSaveMessage("");

		try {
			const realData = await fetchRealProductData(productName);

			// Auto-fill suggested pricing
			setCostPrice(realData.pricing.suggestedCostPrice.toString());
			setSellingPrice(realData.pricing.suggestedSellingPrice.toString());
			setShippingFees(realData.pricing.averageShipping.toString());

			// Show message with data source
			const dataSourceMessage =
				realData.dataSource === "real"
					? "Real market data loaded!"
					: realData.dataSource === "hybrid"
						? "Partial real data loaded (some APIs unavailable)"
						: "Sample data loaded (configure APIs in .env for real data)";

			setSaveMessage(dataSourceMessage);
			setTimeout(() => setSaveMessage(""), 5000);
		} catch (error) {
			console.error("Error fetching real data:", error);
			setSaveMessage("Error fetching data: " + (error instanceof Error ? error.message : "Unknown error"));
		} finally {
			setIsFetchingRealData(false);
		}
	};

	return (
		<Card>
			<CardHeader>
				<div className="flex items-start justify-between gap-4">
					<div>
						<CardTitle>Product Profit Calculator</CardTitle>
						<CardDescription>
							Calculate net profit margin, break-even units, and ROI percentage
						</CardDescription>
					</div>
					<DataSourceIndicator />
				</div>
			</CardHeader>
			<CardContent className="space-y-6">
				<div className="space-y-4">
					<div className="space-y-2">
						<Label htmlFor="product-name">Product Name</Label>
						<div className="flex gap-2">
							<Input
								id="product-name"
								placeholder="Enter product name"
								value={productName}
								onChange={(e) => setProductName(e.target.value)}
								className="flex-1"
							/>
							<Button
								onClick={handleFetchRealData}
								disabled={isFetchingRealData || !productName.trim()}
								variant="outline"
								className="shrink-0"
							>
								{isFetchingRealData ? (
									<>
										<Sparkles className="size-4 mr-2 animate-spin" />
										Fetching...
									</>
								) : (
									<>
										<TrendingUp className="size-4 mr-2" />
										Get Real Data
									</>
								)}
							</Button>
						</div>
						<p className="text-xs text-zinc-500 dark:text-zinc-400">
							Click "Get Real Data" to fetch market pricing and demand from Google Trends & AliExpress
						</p>
					</div>

					<div className="flex items-center justify-between bg-purple-50 dark:bg-purple-950/20 border border-purple-200 dark:border-purple-900 rounded-lg p-4">
						<div className="flex items-center gap-3">
							<Sparkles className="size-5 text-purple-600 dark:text-purple-400" />
							<div>
								<Label htmlFor="auto-predict-toggle" className="cursor-pointer font-medium text-sm">
									Auto-Predict All Fees with AI
								</Label>
								<p className="text-xs text-zinc-600 dark:text-zinc-400 mt-0.5">
									Automatically estimate shipping, platform, CAC, and credit card fees based on market analysis
								</p>
							</div>
						</div>
						<Switch
							id="auto-predict-toggle"
							checked={autoPredictFees}
							onCheckedChange={(checked) => {
								setAutoPredictFees(checked);
								if (!checked) {
									setFeeExplanations(null);
								}
							}}
						/>
					</div>

					<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
						<div className="space-y-2">
							<Label htmlFor="cost-price">Cost Price ($)</Label>
							<Input
								id="cost-price"
								type="number"
								step="0.01"
								placeholder="0.00"
								value={costPrice}
								onChange={(e) => setCostPrice(e.target.value)}
							/>
						</div>

						<div className="space-y-2">
							<Label htmlFor="selling-price">Selling Price ($)</Label>
							<Input
								id="selling-price"
								type="number"
								step="0.01"
								placeholder="0.00"
								value={sellingPrice}
								onChange={(e) => setSellingPrice(e.target.value)}
							/>
						</div>

						<div className="space-y-2">
							<div className="flex items-center gap-2">
								<Label htmlFor="shipping-fees">Shipping Fees ($)</Label>
								{autoPredictFees && (
									<TooltipProvider>
										<Tooltip>
											<TooltipTrigger asChild>
												<Info className="size-3.5 text-purple-600 dark:text-purple-400" />
											</TooltipTrigger>
											<TooltipContent className="max-w-xs">
												<p className="text-xs">{feeExplanations?.shipping || "Estimating..."}</p>
											</TooltipContent>
										</Tooltip>
									</TooltipProvider>
								)}
								{isPredicting && autoPredictFees && (
									<Badge variant="secondary" className="text-xs">
										Predicting...
									</Badge>
								)}
							</div>
							<Input
								id="shipping-fees"
								type="number"
								step="0.01"
								placeholder={autoPredictFees ? "Auto-predicted" : "0.00"}
								value={shippingFees}
								onChange={(e) => setShippingFees(e.target.value)}
								disabled={autoPredictFees}
								className={autoPredictFees ? "bg-purple-50 dark:bg-purple-950/20 border-purple-200 dark:border-purple-800" : ""}
							/>
						</div>

						<div className="space-y-2">
							<div className="flex items-center gap-2">
								<Label htmlFor="platform-fees">Platform Fees ($)</Label>
								{autoPredictFees && (
									<TooltipProvider>
										<Tooltip>
											<TooltipTrigger asChild>
												<Info className="size-3.5 text-purple-600 dark:text-purple-400" />
											</TooltipTrigger>
											<TooltipContent className="max-w-xs">
												<p className="text-xs">{feeExplanations?.platform || "Estimating..."}</p>
											</TooltipContent>
										</Tooltip>
									</TooltipProvider>
								)}
							</div>
							<Input
								id="platform-fees"
								type="number"
								step="0.01"
								placeholder={autoPredictFees ? "Auto-predicted" : "0.00"}
								value={platformFees}
								onChange={(e) => setPlatformFees(e.target.value)}
								disabled={autoPredictFees}
								className={autoPredictFees ? "bg-purple-50 dark:bg-purple-950/20 border-purple-200 dark:border-purple-800" : ""}
							/>
						</div>

						<div className="space-y-2">
							<div className="flex items-center gap-2">
								<Label htmlFor="customer-acquisition-cost">Customer Acquisition Cost ($)</Label>
								<TooltipProvider>
									<Tooltip>
										<TooltipTrigger asChild>
											<Info className="size-3.5 text-blue-600 dark:text-blue-400" />
										</TooltipTrigger>
										<TooltipContent className="max-w-xs">
											<p className="text-xs">Average cost to acquire one customer (ads, marketing, etc.)</p>
										</TooltipContent>
									</Tooltip>
								</TooltipProvider>
							</div>
							<Input
								id="customer-acquisition-cost"
								type="number"
								step="0.01"
								placeholder="0.00"
								value={customerAcquisitionCost}
								onChange={(e) => setCustomerAcquisitionCost(e.target.value)}
							/>
						</div>

						<div className="space-y-2">
							<div className="flex items-center gap-2">
								<Label htmlFor="credit-card-fee">Credit Card Fee (%)</Label>
								<TooltipProvider>
									<Tooltip>
										<TooltipTrigger asChild>
											<Info className="size-3.5 text-blue-600 dark:text-blue-400" />
										</TooltipTrigger>
										<TooltipContent className="max-w-xs">
											<p className="text-xs">Percentage charged by payment processor (typically 2.9% + $0.30)</p>
										</TooltipContent>
									</Tooltip>
								</TooltipProvider>
							</div>
							<Input
								id="credit-card-fee"
								type="number"
								step="0.1"
								placeholder="2.9"
								value={creditCardFeePercent}
								onChange={(e) => setCreditCardFeePercent(e.target.value)}
							/>
						</div>
					</div>

					<div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900 rounded-lg p-4">
						<p className="text-xs text-zinc-600 dark:text-zinc-400">
							<span className="font-medium">Credit Card Fee Amount:</span> ${creditCardFee.toFixed(2)}
							{creditCardFeeRate > 0 && ` (${creditCardFeeRate}% of $${selling.toFixed(2)})`}
						</p>
					</div>
				</div>

				{feeExplanations && (
					<div className="bg-purple-50 dark:bg-purple-950/20 border border-purple-200 dark:border-purple-900 rounded-lg p-4">
						<div className="flex items-center gap-2 mb-3">
							<Sparkles className="size-4 text-purple-600 dark:text-purple-400" />
							<span className="font-medium text-sm">AI-Powered Fee Predictions</span>
							<Badge variant={
								feeExplanations.confidence === "high" ? "default" :
								feeExplanations.confidence === "medium" ? "secondary" : "outline"
							} className="text-xs">
								{feeExplanations.confidence} confidence
							</Badge>
						</div>
						<div className="space-y-3 text-xs text-zinc-600 dark:text-zinc-400">
							<div className="border-l-2 border-blue-400 pl-3">
								<span className="font-medium text-blue-700 dark:text-blue-400">Shipping Fee:</span>
								<p className="mt-1">{feeExplanations.shipping}</p>
							</div>
							<div className="border-l-2 border-green-400 pl-3">
								<span className="font-medium text-green-700 dark:text-green-400">Platform Fee:</span>
								<p className="mt-1">{feeExplanations.platform}</p>
							</div>
							<div className="border-l-2 border-orange-400 pl-3">
								<span className="font-medium text-orange-700 dark:text-orange-400">Customer Acquisition Cost (CAC):</span>
								<p className="mt-1 whitespace-pre-line">{feeExplanations.cac}</p>
							</div>
							<div className="border-l-2 border-purple-400 pl-3">
								<span className="font-medium text-purple-700 dark:text-purple-400">Credit Card Processing:</span>
								<p className="mt-1">{feeExplanations.creditCard}</p>
							</div>
						</div>
					</div>
				)}

				<div className="border-t pt-6">
					<h3 className="text-lg font-semibold mb-4">Results</h3>
					<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
						<div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-4">
							<p className="text-sm text-zinc-600 dark:text-zinc-400 mb-1">Net Profit</p>
							<p className={`text-2xl font-bold ${netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
								${netProfit.toFixed(2)}
							</p>
						</div>

						<div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-4">
							<p className="text-sm text-zinc-600 dark:text-zinc-400 mb-1">Profit Margin</p>
							<p className={`text-2xl font-bold ${profitMargin >= 0 ? 'text-green-600' : 'text-red-600'}`}>
								{profitMargin.toFixed(2)}%
							</p>
						</div>

						<div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-4">
							<p className="text-sm text-zinc-600 dark:text-zinc-400 mb-1">Break-Even Units</p>
							<p className="text-2xl font-bold text-zinc-900 dark:text-zinc-50">
								{breakEvenUnits}
							</p>
						</div>

						<div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-4">
							<p className="text-sm text-zinc-600 dark:text-zinc-400 mb-1">ROI</p>
							<p className={`text-2xl font-bold ${roi >= 0 ? 'text-green-600' : 'text-red-600'}`}>
								{roi.toFixed(2)}%
							</p>
						</div>
					</div>

					<div className="mt-6 bg-zinc-50 dark:bg-zinc-900 rounded-lg p-4">
						<h4 className="text-sm font-semibold mb-3">Cost Breakdown</h4>
						<div className="space-y-2 text-sm">
							<div className="flex justify-between">
								<span className="text-zinc-600 dark:text-zinc-400">Product Cost:</span>
								<span className="font-medium">${cost.toFixed(2)}</span>
							</div>
							<div className="flex justify-between">
								<span className="text-zinc-600 dark:text-zinc-400">Shipping Fees:</span>
								<span className="font-medium">${shipping.toFixed(2)}</span>
							</div>
							<div className="flex justify-between">
								<span className="text-zinc-600 dark:text-zinc-400">Platform Fees:</span>
								<span className="font-medium">${platform.toFixed(2)}</span>
							</div>
							<div className="flex justify-between">
								<span className="text-zinc-600 dark:text-zinc-400">Customer Acquisition Cost (CAC):</span>
								<span className="font-medium">${cac.toFixed(2)}</span>
							</div>
							<div className="flex justify-between">
								<span className="text-zinc-600 dark:text-zinc-400">Credit Card Fee ({creditCardFeeRate}%):</span>
								<span className="font-medium">${creditCardFee.toFixed(2)}</span>
							</div>
							<div className="flex justify-between pt-2 border-t">
								<span className="font-semibold">Total Cost:</span>
								<span className="font-bold">${totalCost.toFixed(2)}</span>
							</div>
							<div className="flex justify-between pt-2 border-t">
								<span className="font-semibold">Selling Price:</span>
								<span className="font-bold text-green-600">${selling.toFixed(2)}</span>
							</div>
							<div className="flex justify-between">
								<span className="font-semibold">Net Profit per Unit:</span>
								<span className={`font-bold ${netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
									${netProfit.toFixed(2)}
								</span>
							</div>
						</div>
					</div>
				</div>

				<div className="flex items-center gap-4">
					<Button onClick={handleSave} disabled={isSaving}>
						<Save className="size-4 mr-2" />
						{isSaving ? "Saving..." : "Save Analysis"}
					</Button>
					{saveMessage && (
						<Badge variant={saveMessage.includes("Error") ? "destructive" : "default"}>
							{saveMessage}
						</Badge>
					)}
				</div>
			</CardContent>
		</Card>
	);
}
