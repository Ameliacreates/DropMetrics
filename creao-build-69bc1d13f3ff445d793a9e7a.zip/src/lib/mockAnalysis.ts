/**
 * Mock analysis functions to simulate AI responses without API calls
 * Based on the Python mock function provided by the user
 */

export interface FeeEstimate {
	shippingFee: number;
	platformFee: number;
	customerAcquisitionCost: number;
	creditCardFeePercent: number;
	confidence: "high" | "medium" | "low";
	explanation: {
		shipping: string;
		platform: string;
		cac: string;
		creditCard: string;
	};
}

export interface MockAnalysisResult {
	product_name: string;
	status: "success" | "error";
	analysis: {
		demand_score: string;
		market_trend: string;
		estimated_margin: string;
		competition_level: string;
		top_competitors: string[];
		marketing_strategy: string;
		final_verdict: string;
	};
}

/**
 * Simulates AI analysis with realistic mock data
 */
export async function analyzeProductMock(productName: string): Promise<MockAnalysisResult> {
	// Simulate network delay (2 seconds)
	await new Promise(resolve => setTimeout(resolve, 2000));

	// Generate varied mock data based on product name characteristics
	const mockData: MockAnalysisResult = {
		product_name: productName,
		status: "success",
		analysis: {
			demand_score: generateDemandScore(productName),
			market_trend: generateMarketTrend(productName),
			estimated_margin: generateEstimatedMargin(productName),
			competition_level: generateCompetitionLevel(productName),
			top_competitors: generateTopCompetitors(productName),
			marketing_strategy: generateMarketingStrategy(productName),
			final_verdict: generateFinalVerdict(productName),
		},
	};

	return mockData;
}

/**
 * Generate demand analysis mock data
 */
export function generateDemandAnalysis(productKeyword: string): string {
	const trends = [
		"Growing rapidly with 45% YoY increase",
		"Stable demand with seasonal peaks in Q4",
		"Increasing (High social media buzz)",
		"Moderate growth, trending on TikTok",
		"Strong and consistent demand year-round",
	];

	const seasonality = [
		"Peak months: November-December (holiday season)",
		"Consistent throughout the year with slight summer dip",
		"Strong summer demand (June-August)",
		"Back-to-school spike (August-September)",
		"Year-round with Q1 surge after New Year",
	];

	const marketSize = [
		"Estimated global market: $2.5B annually",
		"US market size: $850M with 12% growth rate",
		"Niche market: $150M but rapidly expanding",
		"Large established market: $5B+ globally",
		"Emerging market: $500M with high growth potential",
	];

	return `
# Market Demand Analysis for "${productKeyword}"

## Search Volume & Trends
${trends[Math.floor(Math.random() * trends.length)]}
- Monthly search volume: ${Math.floor(Math.random() * 900000) + 100000} searches
- Search trend: ${Math.random() > 0.5 ? "Upward" : "Stable"} over the last 12 months

## Seasonal Demand Patterns
${seasonality[Math.floor(Math.random() * seasonality.length)]}
- Best selling period: ${getRandomSeason()}
- Lower demand period: ${getRandomSeason()}

## Market Size Estimate
${marketSize[Math.floor(Math.random() * marketSize.length)]}
- Expected CAGR: ${(Math.random() * 20 + 5).toFixed(1)}% (2024-2028)
- Market maturity: ${Math.random() > 0.5 ? "Growing" : "Mature"}

## Growth Trajectory
The "${productKeyword}" market shows ${Math.random() > 0.3 ? "positive" : "stable"} growth indicators with strong e-commerce presence.
`;
}

/**
 * Generate competition evaluation mock data
 */
export function generateCompetitionEvaluation(productCategory: string): string {
	const saturationLevels = ["Low", "Medium", "High", "Oversaturated"];
	const saturation = saturationLevels[Math.floor(Math.random() * saturationLevels.length)];

	const minPrice = Math.floor(Math.random() * 50) + 10;
	const maxPrice = minPrice + Math.floor(Math.random() * 100) + 50;
	const avgPrice = Math.floor((minPrice + maxPrice) / 2);

	return `
# Competition Evaluation for "${productCategory}"

## Competitor Pricing Analysis
- **Minimum Price**: $${minPrice}
- **Maximum Price**: $${maxPrice}
- **Average Price**: $${avgPrice}
- Price positioning: ${avgPrice < 50 ? "Budget-friendly" : avgPrice < 100 ? "Mid-range" : "Premium"}

## Market Saturation Level
**${saturation}** - ${getSaturationDescription(saturation)}

## Key Competitors
1. Amazon Choice Brand - Dominant player with 25% market share
2. Specialty Shopify Stores - Growing DTC brands
3. AliExpress Sellers - Budget competition
4. ${generateRandomBrand()} - Emerging competitor
5. ${generateRandomBrand()} - Niche player

## Competitive Advantage Opportunities
- **Unique Value Proposition**: ${getRandomUVP()}
- **Differentiation Strategy**: ${getRandomDifferentiation()}
- **Target Audience**: ${getRandomAudience()}
- **Marketing Channel**: Best suited for ${getRandomChannel()}

## Strategic Recommendations
${saturation === "Low" || saturation === "Medium"
	? "Good opportunity to enter market. Focus on brand building and customer service."
	: "Highly competitive. Requires strong differentiation and marketing budget."}
`;
}

/**
 * Generate business plan mock data
 */
export function generateBusinessPlan(productName: string): {
	executiveSummary: string;
	marketAnalysis: string;
	financialProjections: string;
	operationalStrategy: string;
} {
	return {
		executiveSummary: `
# Executive Summary

## Business Concept
Launch a dropshipping business specializing in "${productName}" targeting online consumers seeking quality and convenience.

## Value Proposition
We offer premium ${productName.toLowerCase()} with exceptional customer service, fast shipping (3-5 days), and a 30-day satisfaction guarantee. Our competitive pricing and curated product selection differentiate us in a crowded market.

## Target Market
Primary demographic: Ages 25-45, tech-savvy online shoppers with disposable income seeking ${getProductCategory(productName)}. Secondary market includes gift buyers and hobbyists.

## Key Success Factors
1. Strategic supplier partnerships ensuring quality and reliability
2. Data-driven marketing focused on social media and influencer partnerships
3. Superior customer experience with responsive support
4. Competitive pricing with healthy 40-60% margins
`,
		marketAnalysis: `
# Market Analysis

## Target Customer Demographics
- **Age Range**: 25-45 years old
- **Income Level**: $45,000-$100,000 annually
- **Location**: United States (primary), Canada, UK (expansion)
- **Shopping Behavior**: Frequent online buyers, mobile-first, value convenience

## Market Size and Growth Potential
The ${productName.toLowerCase()} market is valued at approximately $${Math.floor(Math.random() * 500) + 100}M annually in the US market, with a projected CAGR of ${(Math.random() * 10 + 8).toFixed(1)}% through 2028.

## Competitive Landscape
**Direct Competitors**: Established brands on Amazon, specialized Shopify stores, AliExpress sellers
**Indirect Competitors**: Brick-and-mortar retailers, general e-commerce platforms
**Market Position**: We position as a quality-focused, customer-centric alternative to generic suppliers

## Market Trends and Opportunities
1. Increasing preference for online shopping (up 25% YoY)
2. Social commerce growth on TikTok and Instagram
3. Consumer demand for faster shipping and better service
4. Sustainability and ethical sourcing becoming key differentiators
`,
		financialProjections: `
# Financial Projections

## Startup Costs Breakdown
- **Initial Inventory**: $0 (dropshipping model)
- **Website & E-commerce Platform**: $500-$1,000 (Shopify + apps)
- **Marketing & Advertising**: $2,000 initial budget
- **Business Registration & Legal**: $500
- **Total Startup Investment**: $3,000-$3,500

## Expected Monthly Revenue (First 12 Months)
- **Month 1-3**: $2,000-$5,000 (testing and optimization phase)
- **Month 4-6**: $8,000-$15,000 (scaling phase)
- **Month 7-9**: $20,000-$35,000 (growth phase)
- **Month 10-12**: $40,000-$60,000 (established phase)

## Operating Expenses (Monthly Average)
- **Cost of Goods Sold**: 40% of revenue
- **Marketing & Ads**: 25% of revenue (decreasing over time)
- **Platform Fees**: $80 (Shopify) + 2.9% transaction fees
- **Software & Tools**: $200 (email, analytics, customer service)
- **Customer Service**: $500 (outsourced support)

## Break-Even Analysis
Expected break-even at **Month 4-5** with cumulative revenue of $15,000-$20,000.

## Profit Margins
- **Gross Margin**: 55-65%
- **Net Margin**: 15-25% (increasing as marketing costs decrease)
`,
		operationalStrategy: `
# Operational Strategy

## Supplier Sourcing Strategy
1. **Primary Supplier**: Identify 2-3 reliable suppliers with US/EU warehouses
2. **Backup Suppliers**: Maintain relationships with alternative suppliers for product continuity
3. **Quality Control**: Order samples, implement supplier scorecards
4. **Negotiation**: Secure volume discounts and favorable payment terms

## Order Fulfillment Process
1. **Automated Order Processing**: Integrate Shopify with supplier systems via Oberlo/DSers
2. **Shipping Standards**: 3-5 day delivery for US customers, tracking provided
3. **Quality Assurance**: Random product inspections, customer feedback loops
4. **Returns Management**: 30-day return policy, streamlined process

## Customer Service Approach
1. **Response Time**: Under 4 hours for all inquiries
2. **Channels**: Email, live chat, social media
3. **Knowledge Base**: Comprehensive FAQ and self-service resources
4. **Satisfaction Guarantee**: 30-day money-back guarantee builds trust

## Marketing and Customer Acquisition Channels
1. **Social Media Advertising**: Facebook/Instagram ads targeting lookalike audiences
2. **Content Marketing**: TikTok and Instagram Reels showcasing product benefits
3. **Influencer Partnerships**: Micro-influencers (10k-100k followers) for authentic promotion
4. **Email Marketing**: Automated sequences for abandoned carts and customer retention
5. **SEO & Content**: Blog posts and product guides for organic traffic

## Scaling Strategy
**Phase 1 (Months 1-3)**: Test product-market fit, optimize conversion rates
**Phase 2 (Months 4-6)**: Scale winning ad campaigns, expand product line
**Phase 3 (Months 7-12)**: Diversify traffic sources, build email list, consider private labeling

Key metrics to track: CAC (Customer Acquisition Cost), LTV (Lifetime Value), conversion rate, average order value.
`,
	};
}

// Helper functions
function generateDemandScore(productName: string): string {
	const score = Math.floor(Math.random() * 4) + 6; // 6-10
	return `${score}/10`;
}

function generateMarketTrend(productName: string): string {
	const trends = [
		"Increasing (High social media buzz)",
		"Growing rapidly - viral on TikTok",
		"Stable with seasonal peaks",
		"Trending upward in Q4",
		"Strong momentum in e-commerce",
	];
	return trends[Math.floor(Math.random() * trends.length)];
}

function generateEstimatedMargin(productName: string): string {
	const margins = ["40-50%", "50-60%", "60-70%", "45-55%", "55-65%"];
	return margins[Math.floor(Math.random() * margins.length)];
}

function generateCompetitionLevel(productName: string): string {
	const levels = ["Low", "Medium", "Medium-High", "High"];
	return levels[Math.floor(Math.random() * levels.length)];
}

function generateTopCompetitors(productName: string): string[] {
	const competitors = [
		"Amazon Choice Brand",
		"Specialty Shopify Store",
		"AliExpress Top Seller",
		"Walmart Marketplace",
		"Etsy Featured Shop",
	];
	return competitors.slice(0, Math.floor(Math.random() * 2) + 2);
}

function generateMarketingStrategy(productName: string): string {
	const strategies = [
		"Best suited for short-form video ads (TikTok/Reels).",
		"Strong potential for influencer marketing campaigns.",
		"SEO and content marketing recommended.",
		"Facebook/Instagram ads with carousel format.",
		"Pinterest and visual platforms highly effective.",
	];
	return strategies[Math.floor(Math.random() * strategies.length)];
}

function generateFinalVerdict(productName: string): string {
	const verdicts = [
		"Solid product choice. Low risk for testing.",
		"Excellent opportunity. Highly recommended for beginners.",
		"Good potential with proper marketing. Moderate risk.",
		"Competitive but profitable with strong branding.",
		"Worth testing with small budget. Monitor closely.",
	];
	return verdicts[Math.floor(Math.random() * verdicts.length)];
}

function getRandomSeason(): string {
	const seasons = [
		"Q1 (Jan-Mar)",
		"Q2 (Apr-Jun)",
		"Q3 (Jul-Sep)",
		"Q4 (Oct-Dec)",
		"Holiday Season",
		"Summer months",
		"Back to school",
	];
	return seasons[Math.floor(Math.random() * seasons.length)];
}

function getSaturationDescription(level: string): string {
	const descriptions: Record<string, string> = {
		Low: "Few competitors, good opportunity for new entrants",
		Medium: "Moderate competition, differentiation important",
		High: "Crowded market, requires strong unique value proposition",
		Oversaturated: "Very competitive, challenging for new sellers",
	};
	return descriptions[level] || "Analysis needed";
}

function generateRandomBrand(): string {
	const prefixes = ["Elite", "Prime", "Smart", "Pro", "Ultra", "Mega"];
	const suffixes = ["Direct", "Hub", "Shop", "Store", "Marketplace"];
	return `${prefixes[Math.floor(Math.random() * prefixes.length)]}${suffixes[Math.floor(Math.random() * suffixes.length)]}`;
}

function getRandomUVP(): string {
	const uvps = [
		"Premium quality at competitive prices",
		"Fastest shipping in the category",
		"Eco-friendly and sustainable products",
		"Superior customer service and support",
		"Exclusive designs not available elsewhere",
	];
	return uvps[Math.floor(Math.random() * uvps.length)];
}

function getRandomDifferentiation(): string {
	const strategies = [
		"Focus on customer education and content",
		"Build strong brand community",
		"Offer customization options",
		"Bundle products for higher value",
		"Provide exceptional unboxing experience",
	];
	return strategies[Math.floor(Math.random() * strategies.length)];
}

function getRandomAudience(): string {
	const audiences = [
		"Tech-savvy millennials (25-35)",
		"Home improvement enthusiasts",
		"Fitness and wellness seekers",
		"Busy professionals seeking convenience",
		"Parents looking for quality products",
	];
	return audiences[Math.floor(Math.random() * audiences.length)];
}

function getRandomChannel(): string {
	const channels = [
		"TikTok and Instagram Reels",
		"Facebook and Instagram ads",
		"YouTube product reviews",
		"Pinterest visual marketing",
		"Email marketing campaigns",
	];
	return channels[Math.floor(Math.random() * channels.length)];
}

function getProductCategory(productName: string): string {
	const categories = [
		"quality home products",
		"innovative gadgets",
		"lifestyle accessories",
		"practical solutions",
		"premium essentials",
	];
	return categories[Math.floor(Math.random() * categories.length)];
}

/**
 * Estimate shipping and platform fees based on product price
 * Simulates AI-powered fee prediction using realistic industry data
 */
export async function estimateFees(
	sellingPrice: number,
	productName?: string
): Promise<FeeEstimate> {
	// Simulate API delay (1 second)
	await new Promise(resolve => setTimeout(resolve, 1000));

	// Determine product weight category based on price (heuristic)
	let weightCategory: "light" | "medium" | "heavy";
	let shippingBase: number;

	if (sellingPrice < 20) {
		weightCategory = "light";
		shippingBase = 3.5;
	} else if (sellingPrice < 50) {
		weightCategory = "medium";
		shippingBase = 5.5;
	} else {
		weightCategory = "heavy";
		shippingBase = 8.5;
	}

	// Add some realistic variance
	const shippingVariance = (Math.random() - 0.5) * 2; // ±$1
	const shippingFee = Math.max(2.5, shippingBase + shippingVariance);

	// Platform fees: Typical e-commerce platforms charge 2.9% + $0.30 (Stripe/PayPal)
	// Plus marketplace fees (Shopify, Etsy, Amazon, etc.)
	const paymentProcessingFee = sellingPrice * 0.029 + 0.30;

	// Determine platform type based on product characteristics
	let platformType: "shopify" | "amazon" | "etsy" | "ebay";
	let marketplaceFeeRate: number;

	// Simple heuristic based on price point
	if (sellingPrice < 30) {
		platformType = "etsy";
		marketplaceFeeRate = 0.065; // 6.5% transaction fee
	} else if (sellingPrice < 60) {
		platformType = "shopify";
		marketplaceFeeRate = 0; // Shopify has fixed monthly fee, no per-transaction marketplace fee
	} else if (sellingPrice < 100) {
		platformType = "ebay";
		marketplaceFeeRate = 0.125; // ~12.5% final value fee
	} else {
		platformType = "amazon";
		marketplaceFeeRate = 0.15; // 15% referral fee (typical)
	}

	const marketplaceFee = sellingPrice * marketplaceFeeRate;
	const totalPlatformFee = paymentProcessingFee + marketplaceFee;

	// Determine confidence based on price range
	let confidence: "high" | "medium" | "low";
	if (sellingPrice >= 15 && sellingPrice <= 150) {
		confidence = "high";
	} else if (sellingPrice >= 5 && sellingPrice <= 300) {
		confidence = "medium";
	} else {
		confidence = "low";
	}

	// Calculate Customer Acquisition Cost (CAC) based on product characteristics
	const cacEstimate = estimateCAC(sellingPrice, productName);

	// Credit card processing fee is standard across the industry
	const creditCardFeePercent = 2.9; // Standard Stripe/PayPal rate

	// Generate explanations
	const shippingExplanation = generateShippingExplanation(
		weightCategory,
		shippingFee,
		sellingPrice
	);
	const platformExplanation = generatePlatformExplanation(
		platformType,
		totalPlatformFee,
		sellingPrice,
		marketplaceFeeRate
	);
	const cacExplanation = generateCACExplanation(
		cacEstimate.cac,
		cacEstimate.competitionLevel,
		cacEstimate.demandLevel,
		cacEstimate.recommendedChannels,
		sellingPrice
	);
	const creditCardExplanation = `Standard payment processing fee of ${creditCardFeePercent}% (typical for Stripe, PayPal, Square). Industry standard for secure online transactions.`;

	return {
		shippingFee: parseFloat(shippingFee.toFixed(2)),
		platformFee: parseFloat(totalPlatformFee.toFixed(2)),
		customerAcquisitionCost: parseFloat(cacEstimate.cac.toFixed(2)),
		creditCardFeePercent,
		confidence,
		explanation: {
			shipping: shippingExplanation,
			platform: platformExplanation,
			cac: cacExplanation,
			creditCard: creditCardExplanation,
		},
	};
}

/**
 * Estimate Customer Acquisition Cost based on product price, competition, and demand
 * Uses intelligent heuristics based on dropshipping industry benchmarks
 */
function estimateCAC(
	sellingPrice: number,
	productName?: string
): {
	cac: number;
	competitionLevel: "low" | "medium" | "high";
	demandLevel: "low" | "medium" | "high";
	recommendedChannels: string[];
} {
	// Determine competition level based on price point (heuristic)
	// Lower-priced items typically have higher competition
	let competitionLevel: "low" | "medium" | "high";
	let baseCAC: number;

	if (sellingPrice < 25) {
		competitionLevel = "high";
		baseCAC = sellingPrice * 0.35; // 35% of price for highly competitive markets
	} else if (sellingPrice < 75) {
		competitionLevel = "medium";
		baseCAC = sellingPrice * 0.25; // 25% for moderate competition
	} else {
		competitionLevel = "low";
		baseCAC = sellingPrice * 0.18; // 18% for less competitive, higher-value items
	}

	// Determine demand level (inverse relationship with price in dropshipping)
	let demandLevel: "low" | "medium" | "high";
	if (sellingPrice < 30) {
		demandLevel = "high"; // Impulse buy range
	} else if (sellingPrice < 80) {
		demandLevel = "medium"; // Considered purchase
	} else {
		demandLevel = "low"; // Requires more convincing
	}

	// Adjust CAC based on demand level
	// Higher demand = easier to convert = lower CAC
	let demandMultiplier = 1.0;
	if (demandLevel === "high") {
		demandMultiplier = 0.85; // 15% reduction for high demand
	} else if (demandLevel === "low") {
		demandMultiplier = 1.25; // 25% increase for low demand
	}

	// Calculate final CAC
	let finalCAC = baseCAC * demandMultiplier;

	// Add realistic variance (±20%)
	const variance = (Math.random() - 0.5) * 0.4 * finalCAC;
	finalCAC = Math.max(2.0, finalCAC + variance); // Minimum $2 CAC

	// Recommended marketing channels based on product characteristics
	const recommendedChannels: string[] = [];

	if (sellingPrice < 30) {
		// Low-price impulse buys
		recommendedChannels.push("TikTok Ads", "Instagram Reels", "Facebook Feed");
	} else if (sellingPrice < 80) {
		// Mid-range products
		recommendedChannels.push("Facebook Ads", "Instagram Stories", "Google Shopping");
	} else {
		// Premium products
		recommendedChannels.push("Google Ads", "YouTube Pre-roll", "Influencer Marketing");
	}

	return {
		cac: finalCAC,
		competitionLevel,
		demandLevel,
		recommendedChannels,
	};
}

/**
 * Generate detailed explanation for CAC estimate
 */
function generateCACExplanation(
	cac: number,
	competitionLevel: "low" | "medium" | "high",
	demandLevel: "low" | "medium" | "high",
	recommendedChannels: string[],
	sellingPrice: number
): string {
	const competitionDescriptions = {
		low: "Low competition - fewer advertisers competing for the same audience",
		medium: "Medium competition - moderate ad costs with good targeting opportunities",
		high: "High competition - many sellers targeting similar customers, higher ad costs",
	};

	const demandDescriptions = {
		low: "Lower demand - requires more touchpoints to convert",
		medium: "Moderate demand - balanced conversion rates",
		high: "High demand - impulse-buy category with easier conversions",
	};

	const channelList = recommendedChannels.join(", ");

	const explanation = `Estimated at $${cac.toFixed(2)} per customer based on:
• ${competitionDescriptions[competitionLevel]}
• ${demandDescriptions[demandLevel]}
• Price point: $${sellingPrice.toFixed(2)} (affects target audience and conversion rates)
• Recommended channels: ${channelList}

Industry benchmark: CAC typically ranges from 15-35% of selling price for dropshipping. This estimate assumes Facebook/Instagram ads with standard targeting and a 2-3% conversion rate.`;

	return explanation;
}

function generateShippingExplanation(
	weight: "light" | "medium" | "heavy",
	fee: number,
	price: number
): string {
	const weightDescriptions = {
		light: "lightweight items (under 1 lb)",
		medium: "standard items (1-3 lbs)",
		heavy: "larger items (3+ lbs)",
	};

	const methods = {
		light: "USPS First Class or ePacket",
		medium: "USPS Priority or UPS Ground",
		heavy: "UPS/FedEx Ground",
	};

	return `Estimated for ${weightDescriptions[weight]} using ${methods[weight]}. Based on typical dropshipping rates for products in the $${price.toFixed(0)} price range.`;
}

function generatePlatformExplanation(
	platform: "shopify" | "amazon" | "etsy" | "ebay",
	totalFee: number,
	price: number,
	marketplaceRate: number
): string {
	const platformNames = {
		shopify: "Shopify",
		amazon: "Amazon FBA",
		etsy: "Etsy",
		ebay: "eBay",
	};

	const feeBreakdown = {
		shopify: `${(price * 0.029 + 0.30).toFixed(2)} payment processing (2.9% + $0.30)`,
		amazon: `${(price * 0.029 + 0.30).toFixed(2)} payment + ${(price * marketplaceRate).toFixed(2)} referral (15%)`,
		etsy: `${(price * 0.029 + 0.30).toFixed(2)} payment + ${(price * marketplaceRate).toFixed(2)} transaction (6.5%)`,
		ebay: `${(price * 0.029 + 0.30).toFixed(2)} payment + ${(price * marketplaceRate).toFixed(2)} final value (~12.5%)`,
	};

	return `Estimated for ${platformNames[platform]} platform. Includes ${feeBreakdown[platform]}. Total: $${totalFee.toFixed(2)}`;
}
