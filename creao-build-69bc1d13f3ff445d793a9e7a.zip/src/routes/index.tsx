import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calculator, TrendingUp, Users, LineChart, FileText, GitCompare, Award } from "lucide-react";
import { ProfitCalculator } from "@/components/ProfitCalculator";
import { DemandAnalysis } from "@/components/DemandAnalysis";
import { CompetitionEvaluation } from "@/components/CompetitionEvaluation";
import { FinancialProjections } from "@/components/FinancialProjections";
import { BusinessPlanExport } from "@/components/BusinessPlanExport";
import { ProductComparison } from "@/components/ProductComparison";
import { SuccessDashboard } from "@/components/SuccessDashboard";
import { ApiModeToggle } from "@/components/ApiModeToggle";
import { ProductProvider } from "@/contexts/ProductContext";
import { ParallaxBackground } from "@/components/ParallaxBackground";

export const Route = createFileRoute("/")({
	component: App,
});

function App() {
	const [activeTab, setActiveTab] = useState("calculator");

	return (
		<ProductProvider>
			<ParallaxBackground />
			<div className="min-h-screen relative" style={{ background: 'transparent' }}>
				<div className="container mx-auto px-4 py-8 relative z-10">
					<div className="mb-8">
						<div className="flex items-start justify-between gap-4 mb-4">
							<div>
								<h1 className="text-6xl font-bold mb-1" style={{ color: '#00008B' }}>
									Dropmetrics
								</h1>
								<p className="text-lg italic mb-2" style={{ color: '#000000' }}>
									Unlock your dropshipping potential
								</p>
								<p className="text-sm" style={{ color: '#000000' }}>
									Analyze profit margins, market demand, competition, and generate comprehensive business plans
								</p>
							</div>
							<ApiModeToggle />
						</div>
					</div>

				<Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
					<TabsList className="grid w-full grid-cols-7 mb-6 h-auto gap-1 p-1" style={{ backgroundColor: 'var(--background-lighter)' }}>
						<TabsTrigger
							value="calculator"
							className="flex items-center gap-2 data-[state=active]:text-white transition-colors"
							style={{
								'--tw-bg-opacity': '1',
								backgroundColor: activeTab === 'calculator' ? 'var(--primary)' : 'transparent'
							} as React.CSSProperties}
						>
							<Calculator className="size-4" />
							<span className="hidden sm:inline">Calculator</span>
						</TabsTrigger>
						<TabsTrigger
							value="success"
							className="flex items-center gap-2 data-[state=active]:text-white transition-colors"
							style={{
								backgroundColor: activeTab === 'success' ? 'var(--success)' : 'transparent'
							} as React.CSSProperties}
						>
							<Award className="size-4" />
							<span className="hidden sm:inline">Success</span>
						</TabsTrigger>
						<TabsTrigger
							value="demand"
							className="flex items-center gap-2 data-[state=active]:text-white transition-colors"
							style={{
								backgroundColor: activeTab === 'demand' ? 'var(--secondary)' : 'transparent'
							} as React.CSSProperties}
						>
							<TrendingUp className="size-4" />
							<span className="hidden sm:inline">Demand</span>
						</TabsTrigger>
						<TabsTrigger
							value="competition"
							className="flex items-center gap-2 data-[state=active]:text-white transition-colors"
							style={{
								backgroundColor: activeTab === 'competition' ? 'var(--warning)' : 'transparent'
							} as React.CSSProperties}
						>
							<Users className="size-4" />
							<span className="hidden sm:inline">Competition</span>
						</TabsTrigger>
						<TabsTrigger
							value="projections"
							className="flex items-center gap-2 data-[state=active]:text-white transition-colors"
							style={{
								backgroundColor: activeTab === 'projections' ? 'var(--primary-light)' : 'transparent'
							} as React.CSSProperties}
						>
							<LineChart className="size-4" />
							<span className="hidden sm:inline">Projections</span>
						</TabsTrigger>
						<TabsTrigger
							value="business-plan"
							className="flex items-center gap-2 data-[state=active]:text-white transition-colors"
							style={{
								backgroundColor: activeTab === 'business-plan' ? 'var(--secondary-light)' : 'transparent'
							} as React.CSSProperties}
						>
							<FileText className="size-4" />
							<span className="hidden sm:inline">Business Plan</span>
						</TabsTrigger>
						<TabsTrigger
							value="comparison"
							className="flex items-center gap-2 data-[state=active]:text-white transition-colors"
							style={{
								backgroundColor: activeTab === 'comparison' ? 'var(--danger)' : 'transparent'
							} as React.CSSProperties}
						>
							<GitCompare className="size-4" />
							<span className="hidden sm:inline">Compare</span>
						</TabsTrigger>
					</TabsList>

					<TabsContent value="calculator">
						<ProfitCalculator />
					</TabsContent>

					<TabsContent value="success">
						<SuccessDashboard />
					</TabsContent>

					<TabsContent value="demand">
						<DemandAnalysis />
					</TabsContent>

					<TabsContent value="competition">
						<CompetitionEvaluation />
					</TabsContent>

					<TabsContent value="projections">
						<FinancialProjections />
					</TabsContent>

					<TabsContent value="business-plan">
						<BusinessPlanExport />
					</TabsContent>

					<TabsContent value="comparison">
						<ProductComparison />
					</TabsContent>
				</Tabs>
				</div>
			</div>
		</ProductProvider>
	);
}
