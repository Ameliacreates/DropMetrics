/**
 * Demo script showing how mock analysis works
 * Based on the Python example provided by the user
 */

import { analyzeProductMock } from "./mockAnalysis";

/**
 * Runs a demo analysis and prints results to console
 * This demonstrates the mock functionality without needing the UI
 */
export async function runMockDemo(productName: string = "Ergonomic Desk Lamp") {
	console.log(`🔍 Analyzing product: ${productName}...`);
	console.log("(Simulating AI thinking time - 2 seconds)");

	const result = await analyzeProductMock(productName);

	console.log("\n--- Analysis Report ---");
	console.log(`Product: ${result.product_name}`);
	console.log(`Status: ${result.status}`);
	console.log("\nAnalysis Details:");

	for (const [key, value] of Object.entries(result.analysis)) {
		const formattedKey = key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase());
		if (Array.isArray(value)) {
			console.log(`${formattedKey}:`);
			value.forEach((item, index) => console.log(`  ${index + 1}. ${item}`));
		} else {
			console.log(`${formattedKey}: ${value}`);
		}
	}

	console.log("\n✅ Mock analysis complete!");
	console.log("💡 This data was generated locally without any API calls.");

	return result;
}

// Example usage - you can call this from browser console:
// import { runMockDemo } from '@/lib/mockDemo';
// runMockDemo("Smart Water Bottle");

/**
 * Compare this implementation to the original Python version:
 *
 * Python:
 * def analyze_product_mock(product_name):
 *     print(f"🔍 Analyzing product: {product_name}...")
 *     time.sleep(2)
 *     mock_data = {
 *         "product_name": product_name,
 *         "status": "success",
 *         "analysis": {...}
 *     }
 *     return mock_data
 *
 * TypeScript:
 * async function analyzeProductMock(productName: string): Promise<MockAnalysisResult> {
 *     await new Promise(resolve => setTimeout(resolve, 2000));
 *     const mockData: MockAnalysisResult = {
 *         product_name: productName,
 *         status: "success",
 *         analysis: {...}
 *     };
 *     return mockData;
 * }
 *
 * Both versions:
 * 1. Simulate 2-second processing delay
 * 2. Return structured mock data
 * 3. Include product name, status, and analysis details
 * 4. Work without external APIs
 */
