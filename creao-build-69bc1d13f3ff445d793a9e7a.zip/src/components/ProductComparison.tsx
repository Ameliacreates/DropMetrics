import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Trash2, RefreshCw, Eraser } from "lucide-react";
import { ProductAnalysisORM, type ProductAnalysisModel } from "@/sdk/database/orm/orm_product_analysis";
import { getUserId } from "@/sdk/core/auth";
import { localDB } from "@/lib/localStorageDB";
import {
	AlertDialog,
	AlertDialogAction,
	AlertDialogCancel,
	AlertDialogContent,
	AlertDialogDescription,
	AlertDialogFooter,
	AlertDialogHeader,
	AlertDialogTitle,
	AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export function ProductComparison() {
	const [products, setProducts] = useState<ProductAnalysisModel[]>([]);
	const [isLoading, setIsLoading] = useState(true);

	const loadProducts = async () => {
		setIsLoading(true);
		try {
			const userId = getUserId();
			let remoteProducts: ProductAnalysisModel[] = [];

			try {
				const orm = ProductAnalysisORM.getInstance();
				remoteProducts = userId
					? await orm.getProductAnalysisByUserId(userId)
					: await orm.getAllProductAnalysis();
			} catch {
				// Remote unavailable — rely solely on local data
			}

			// Merge with locally saved records (avoid duplicates by id)
			const localProducts = userId
				? localDB.getByUserId(userId)
				: localDB.getAll();
			const remoteIds = new Set(remoteProducts.map((p) => p.id));
			const merged = [
				...remoteProducts,
				...localProducts.filter((p) => !remoteIds.has(p.id)),
			];

			setProducts(merged.slice(0, 10));
		} catch (error) {
			console.error("Error loading products:", error);
		} finally {
			setIsLoading(false);
		}
	};

	useEffect(() => {
		loadProducts();
	}, []);

	const handleDelete = async (id: string) => {
		try {
			// Delete from local store (always succeeds)
			localDB.deleteById(id);
			// Best-effort delete from remote
			try {
				const orm = ProductAnalysisORM.getInstance();
				await orm.deleteProductAnalysisById(id);
			} catch { /* ignore */ }
			await loadProducts();
		} catch (error) {
			console.error("Error deleting product:", error);
		}
	};

	const handleClearAll = async () => {
		try {
			localDB.clear();
			try {
				const orm = ProductAnalysisORM.getInstance();
				for (const product of products) {
					await orm.deleteProductAnalysisById(product.id);
				}
			} catch { /* ignore */ }
			await loadProducts();
		} catch (error) {
			console.error("Error clearing all products:", error);
		}
	};

	const getBestProduct = () => {
		if (products.length === 0) return null;
		return products.reduce((best, current) =>
			current.roi > best.roi ? current : best
		);
	};

	const bestProduct = getBestProduct();

	return (
		<Card>
			<CardHeader>
				<div className="flex items-center justify-between">
					<div>
						<CardTitle>Product Comparison Dashboard</CardTitle>
						<CardDescription>
							Compare saved products side-by-side with visual metrics
						</CardDescription>
					</div>
					<div className="flex items-center gap-2">
						<Button onClick={loadProducts} variant="outline" size="sm">
							<RefreshCw className="size-4 mr-2" />
							Refresh
						</Button>
						{products.length > 0 && (
							<AlertDialog>
								<AlertDialogTrigger asChild>
									<Button variant="outline" size="sm" className="text-red-600 hover:text-red-700">
										<Eraser className="size-4 mr-2" />
										Clear All
									</Button>
								</AlertDialogTrigger>
								<AlertDialogContent>
									<AlertDialogHeader>
										<AlertDialogTitle>Clear All Products?</AlertDialogTitle>
										<AlertDialogDescription>
											This will permanently delete all {products.length} saved product{products.length !== 1 ? 's' : ''} from your comparison dashboard. This action cannot be undone.
										</AlertDialogDescription>
									</AlertDialogHeader>
									<AlertDialogFooter>
										<AlertDialogCancel>Cancel</AlertDialogCancel>
										<AlertDialogAction
											onClick={handleClearAll}
											className="bg-red-600 hover:bg-red-700"
										>
											Clear All
										</AlertDialogAction>
									</AlertDialogFooter>
								</AlertDialogContent>
							</AlertDialog>
						)}
					</div>
				</div>
			</CardHeader>
			<CardContent>
				{isLoading ? (
					<div className="text-center py-8 text-zinc-600 dark:text-zinc-400">
						Loading products...
					</div>
				) : products.length === 0 ? (
					<div className="text-center py-8 text-zinc-600 dark:text-zinc-400">
						No saved products yet. Use the Profit Calculator to save your first analysis.
					</div>
				) : (
					<div className="space-y-6">
						{bestProduct && (
							<div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-900 rounded-lg p-4">
								<div className="flex items-center gap-2 mb-2">
									<Badge className="bg-green-600">Best ROI</Badge>
									<span className="font-semibold">{bestProduct.product_name}</span>
								</div>
								<p className="text-sm text-zinc-600 dark:text-zinc-400">
									ROI: {bestProduct.roi.toFixed(2)}% | Profit Margin: {bestProduct.profit_margin.toFixed(2)}%
								</p>
							</div>
						)}

						<div className="overflow-x-auto">
							<table className="w-full text-sm">
								<thead className="border-b">
									<tr className="text-left">
										<th className="p-2">Product</th>
										<th className="p-2">Cost</th>
										<th className="p-2">Price</th>
										<th className="p-2">Margin</th>
										<th className="p-2">ROI</th>
										<th className="p-2">Break-Even</th>
										<th className="p-2">Actions</th>
									</tr>
								</thead>
								<tbody>
									{products.map((product) => (
										<tr key={product.id} className="border-b hover:bg-zinc-50 dark:hover:bg-zinc-900">
											<td className="p-2 font-medium">{product.product_name}</td>
											<td className="p-2">${product.cost_price.toFixed(2)}</td>
											<td className="p-2">${product.selling_price.toFixed(2)}</td>
											<td className={`p-2 font-medium ${product.profit_margin >= 0 ? 'text-green-600' : 'text-red-600'}`}>
												{product.profit_margin.toFixed(2)}%
											</td>
											<td className={`p-2 font-medium ${product.roi >= 0 ? 'text-green-600' : 'text-red-600'}`}>
												{product.roi.toFixed(2)}%
											</td>
											<td className="p-2">{product.break_even_units} units</td>
											<td className="p-2">
												<Button
													size="sm"
													variant="ghost"
													onClick={() => handleDelete(product.id)}
												>
													<Trash2 className="size-4 text-red-600" />
												</Button>
											</td>
										</tr>
									))}
								</tbody>
							</table>
						</div>

						<div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t">
							<div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-4">
								<p className="text-sm text-zinc-600 dark:text-zinc-400 mb-1">Total Products</p>
								<p className="text-2xl font-bold">{products.length}</p>
							</div>

							<div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-4">
								<p className="text-sm text-zinc-600 dark:text-zinc-400 mb-1">Avg Profit Margin</p>
								<p className="text-2xl font-bold text-green-600">
									{(products.reduce((sum, p) => sum + p.profit_margin, 0) / products.length).toFixed(2)}%
								</p>
							</div>

							<div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-4">
								<p className="text-sm text-zinc-600 dark:text-zinc-400 mb-1">Avg ROI</p>
								<p className="text-2xl font-bold text-green-600">
									{(products.reduce((sum, p) => sum + p.roi, 0) / products.length).toFixed(2)}%
								</p>
							</div>
						</div>
					</div>
				)}
			</CardContent>
		</Card>
	);
}
