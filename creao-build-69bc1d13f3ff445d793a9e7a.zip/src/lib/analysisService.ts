/**
 * Unified Analysis Service
 * Intelligently switches between mock data and real AI services
 * ALL SERVICES ARE COMMERCIAL-USE FRIENDLY
 *
 * Priority order:
 * 1. Perplexity AI (commercial license included) - PRIMARY
 * 2. Gemini AI (commercial use allowed) - FALLBACK
 * 3. Mock data - LAST RESORT
 */

import {
	generateDemandAnalysis as generateDemandAnalysisMock,
	generateCompetitionEvaluation as generateCompetitionEvaluationMock,
	generateBusinessPlan as generateBusinessPlanMock,
	estimateFees as estimateFeesMock,
	type FeeEstimate,
} from "./mockAnalysis";

import {
	generateDemandAnalysisWithAI,
	generateCompetitionEvaluationWithAI,
	generateBusinessPlanWithAI,
	estimateFeesWithAI,
	isGeminiConfigured,
} from "./geminiService";

import {
	generateDemandAnalysisCommercial,
	generateCompetitionEvaluationCommercial,
	generateBusinessPlanCommercial,
	estimateFeesCommercial,
	isCommercialApiConfigured,
} from "./commercialAnalysisService";

import { useApiMode } from "./apiMode";

/**
 * Generate demand analysis
 * Priority: Perplexity AI > Gemini AI > Mock Data
 * ALL OPTIONS ARE COMMERCIAL-USE FRIENDLY
 */
export async function generateDemandAnalysis(
	productKeyword: string,
	forceMock = false
): Promise<string> {
	// Check API mode preference
	const useMockData = useApiMode.getState().useMockData;

	if (forceMock || useMockData) {
		return generateDemandAnalysisMock(productKeyword);
	}

	// Try Perplexity AI first (COMMERCIAL LICENSE INCLUDED)
	if (isCommercialApiConfigured()) {
		try {
			return await generateDemandAnalysisCommercial(productKeyword);
		} catch (error) {
			console.warn("Perplexity API failed, trying Gemini fallback:", error);
		}
	}

	// Try Gemini AI as fallback (also commercial-friendly)
	if (isGeminiConfigured()) {
		try {
			return await generateDemandAnalysisWithAI(productKeyword);
		} catch (error) {
			console.warn("Gemini API failed, falling back to mock:", error);
			return generateDemandAnalysisMock(productKeyword);
		}
	}

	// Fallback to mock if no AI configured
	return generateDemandAnalysisMock(productKeyword);
}

/**
 * Generate competition evaluation
 * Priority: Perplexity AI > Gemini AI > Mock Data
 * ALL OPTIONS ARE COMMERCIAL-USE FRIENDLY
 */
export async function generateCompetitionEvaluation(
	productCategory: string,
	forceMock = false
): Promise<string> {
	const useMockData = useApiMode.getState().useMockData;

	if (forceMock || useMockData) {
		return generateCompetitionEvaluationMock(productCategory);
	}

	// Try Perplexity AI first (COMMERCIAL LICENSE INCLUDED)
	if (isCommercialApiConfigured()) {
		try {
			return await generateCompetitionEvaluationCommercial(productCategory);
		} catch (error) {
			console.warn("Perplexity API failed, trying Gemini fallback:", error);
		}
	}

	// Try Gemini AI as fallback
	if (isGeminiConfigured()) {
		try {
			return await generateCompetitionEvaluationWithAI(productCategory);
		} catch (error) {
			console.warn("Gemini API failed, falling back to mock:", error);
			return generateCompetitionEvaluationMock(productCategory);
		}
	}

	return generateCompetitionEvaluationMock(productCategory);
}

/**
 * Generate business plan
 * Priority: Perplexity AI > Gemini AI > Mock Data
 * ALL OPTIONS ARE COMMERCIAL-USE FRIENDLY
 */
export async function generateBusinessPlan(
	productName: string,
	forceMock = false
): Promise<{
	executiveSummary: string;
	marketAnalysis: string;
	financialProjections: string;
	operationalStrategy: string;
}> {
	const useMockData = useApiMode.getState().useMockData;

	if (forceMock || useMockData) {
		return generateBusinessPlanMock(productName);
	}

	// Try Perplexity AI first (COMMERCIAL LICENSE INCLUDED)
	if (isCommercialApiConfigured()) {
		try {
			return await generateBusinessPlanCommercial(productName);
		} catch (error) {
			console.warn("Perplexity API failed, trying Gemini fallback:", error);
		}
	}

	// Try Gemini AI as fallback
	if (isGeminiConfigured()) {
		try {
			return await generateBusinessPlanWithAI(productName);
		} catch (error) {
			console.warn("Gemini API failed, falling back to mock:", error);
			return generateBusinessPlanMock(productName);
		}
	}

	return generateBusinessPlanMock(productName);
}

/**
 * Estimate fees with AI
 * Priority: Perplexity AI > Gemini AI > Mock Data
 * ALL OPTIONS ARE COMMERCIAL-USE FRIENDLY
 */
export async function estimateFees(
	sellingPrice: number,
	productName?: string,
	forceMock = false
): Promise<FeeEstimate> {
	const useMockData = useApiMode.getState().useMockData;

	if (forceMock || useMockData) {
		return await estimateFeesMock(sellingPrice, productName);
	}

	// Try Perplexity AI first (COMMERCIAL LICENSE INCLUDED)
	if (isCommercialApiConfigured()) {
		try {
			return await estimateFeesCommercial(sellingPrice, productName);
		} catch (error) {
			console.warn("Perplexity API failed, trying Gemini fallback:", error);
		}
	}

	// Try Gemini AI as fallback
	if (isGeminiConfigured()) {
		try {
			return await estimateFeesWithAI(sellingPrice, productName);
		} catch (error) {
			console.warn("Gemini API failed, falling back to mock:", error);
			return await estimateFeesMock(sellingPrice, productName);
		}
	}

	return await estimateFeesMock(sellingPrice, productName);
}

/**
 * Get current analysis service status
 * Shows which commercial-friendly API is active
 */
export function getAnalysisServiceStatus(): {
	mode: "mock" | "ai" | "auto";
	provider: "mock" | "perplexity" | "gemini";
	configured: boolean;
	commercialLicense: boolean;
	message: string;
} {
	const useMockData = useApiMode.getState().useMockData;
	const perplexityConfigured = isCommercialApiConfigured();
	const geminiConfigured = isGeminiConfigured();

	if (useMockData) {
		return {
			mode: "mock",
			provider: "mock",
			configured: true,
			commercialLicense: true,
			message: "Using mock data (API Mode: Mock)",
		};
	}

	if (perplexityConfigured) {
		return {
			mode: "ai",
			provider: "perplexity",
			configured: true,
			commercialLicense: true,
			message: "✅ Using Perplexity AI (Commercial License Included) - Safe for SaaS",
		};
	}

	if (geminiConfigured) {
		return {
			mode: "ai",
			provider: "gemini",
			configured: true,
			commercialLicense: true,
			message: "✅ Using Google Gemini AI (Commercial Use Allowed)",
		};
	}

	return {
		mode: "auto",
		provider: "mock",
		configured: false,
		commercialLicense: true,
		message: "No AI configured. Using mock data as fallback. Add VITE_PERPLEXITY_API_KEY for real data.",
	};
}
