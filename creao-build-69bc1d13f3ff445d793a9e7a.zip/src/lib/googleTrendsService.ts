/**
 * Google Trends Integration Service
 * Provides real market demand data using Google Trends API
 *
 * Note: Uses unofficial Google Trends API (google-trends-api package)
 * For production, consider using Google's official APIs or SerpApi
 */

export interface TrendsData {
	keyword: string;
	averageInterest: number; // 0-100 scale
	trend: "rising" | "stable" | "declining";
	relatedQueries: string[];
	seasonalPeaks: string[];
	confidence: number; // 0-100
}

/**
 * Fetch Google Trends data for a product keyword
 * This is a mock implementation - in production, you would:
 * 1. Install: npm install google-trends-api
 * 2. Use the actual API or SerpApi (https://serpapi.com/google-trends-api)
 */
export async function fetchGoogleTrends(
	productKeyword: string,
	region = "US"
): Promise<TrendsData> {
	// Mock implementation for now
	// TODO: Replace with real Google Trends API call

	// Simulate API delay
	await new Promise(resolve => setTimeout(resolve, 500));

	// Generate realistic mock data based on keyword
	const interest = Math.floor(Math.random() * 60) + 20; // 20-80
	const trendDirection = interest > 60 ? "rising" : interest > 40 ? "stable" : "declining";

	return {
		keyword: productKeyword,
		averageInterest: interest,
		trend: trendDirection,
		relatedQueries: [
			`${productKeyword} reviews`,
			`best ${productKeyword}`,
			`${productKeyword} price`,
			`buy ${productKeyword} online`,
		],
		seasonalPeaks: ["November", "December", "January"],
		confidence: 75,
	};
}

/**
 * Real Implementation Guide:
 *
 * Option 1: Using SerpApi (Recommended - Most Reliable)
 * --------------------------------------------------------
 * 1. Sign up at https://serpapi.com (100 free searches/month)
 * 2. Get API key
 * 3. Add to .env: VITE_SERPAPI_KEY=your_key_here
 * 4. Install: npm install serpapi
 *
 * Example code:
 * ```typescript
 * import { getJson } from "serpapi";
 *
 * const response = await getJson({
 *   engine: "google_trends",
 *   q: productKeyword,
 *   api_key: import.meta.env.VITE_SERPAPI_KEY,
 *   data_type: "TIMESERIES",
 * });
 *
 * return {
 *   keyword: productKeyword,
 *   averageInterest: response.interest_over_time.timeline_data[0].values[0].value,
 *   trend: calculateTrend(response.interest_over_time.timeline_data),
 *   relatedQueries: response.related_queries.top.map(q => q.query),
 *   seasonalPeaks: findPeaks(response.interest_over_time.timeline_data),
 *   confidence: 95,
 * };
 * ```
 *
 * Option 2: Using google-trends-api (Free but Unreliable)
 * --------------------------------------------------------
 * 1. Install: npm install google-trends-api
 * 2. No API key needed, but rate-limited
 *
 * Example code:
 * ```typescript
 * import googleTrends from "google-trends-api";
 *
 * const results = await googleTrends.interestOverTime({
 *   keyword: productKeyword,
 *   geo: region,
 * });
 * const data = JSON.parse(results);
 * // Parse and return formatted data
 * ```
 *
 * Option 3: Using RapidAPI Google Trends
 * --------------------------------------------------------
 * 1. Sign up at https://rapidapi.com/
 * 2. Subscribe to Google Trends API
 * 3. Add to .env: VITE_RAPIDAPI_KEY=your_key_here
 */

/**
 * Get demand score from trends data
 */
export function calculateDemandScore(trendsData: TrendsData): number {
	let score = trendsData.averageInterest;

	// Boost for rising trends
	if (trendsData.trend === "rising") {
		score += 15;
	} else if (trendsData.trend === "declining") {
		score -= 15;
	}

	// Cap at 100
	return Math.min(100, Math.max(0, score));
}

/**
 * Check if Google Trends is configured
 */
export function isGoogleTrendsConfigured(): boolean {
	// Check for SerpApi key
	const serpApiKey = import.meta.env.VITE_SERPAPI_KEY;
	if (serpApiKey && serpApiKey !== "your_serpapi_key_here") {
		return true;
	}

	// Check for RapidAPI key
	const rapidApiKey = import.meta.env.VITE_RAPIDAPI_KEY;
	if (rapidApiKey && rapidApiKey !== "your_rapidapi_key_here") {
		return true;
	}

	return false;
}
