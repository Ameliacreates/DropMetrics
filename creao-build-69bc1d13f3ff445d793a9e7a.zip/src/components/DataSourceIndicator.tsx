/**
 * Data Source Indicator Component
 * Shows users which real data sources are active
 */

import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Info, CheckCircle2, AlertCircle } from "lucide-react";
import { isRealDataAvailable } from "@/lib/realDataProfitService";

export function DataSourceIndicator() {
	const status = isRealDataAvailable();

	const getStatusColor = () => {
		if (status.googleTrends && status.aliexpress) {
			return "bg-green-100 dark:bg-green-950/30 text-green-700 dark:text-green-300 border-green-300 dark:border-green-800";
		}
		if (status.anyAvailable) {
			return "bg-yellow-100 dark:bg-yellow-950/30 text-yellow-700 dark:text-yellow-300 border-yellow-300 dark:border-yellow-800";
		}
		return "bg-blue-100 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300 border-blue-300 dark:border-blue-800";
	};

	const getStatusIcon = () => {
		if (status.googleTrends && status.aliexpress) {
			return <CheckCircle2 className="size-4" />;
		}
		if (status.anyAvailable) {
			return <AlertCircle className="size-4" />;
		}
		return <Info className="size-4" />;
	};

	const getStatusText = () => {
		if (status.googleTrends && status.aliexpress) {
			return "Real Data Active";
		}
		if (status.googleTrends) {
			return "Trends Active";
		}
		if (status.aliexpress) {
			return "Pricing Active";
		}
		return "Mock Data Mode";
	};

	const getDetailedInfo = () => {
		const parts: string[] = [];

		if (status.googleTrends) {
			parts.push("✅ Google Trends: Real market demand data");
		} else {
			parts.push("⚠️ Google Trends: Using sample data (Configure VITE_SERPAPI_KEY)");
		}

		if (status.aliexpress) {
			parts.push("✅ AliExpress: Real supplier pricing");
		} else {
			parts.push("⚠️ AliExpress: Using estimated pricing (Configure VITE_RAPIDAPI_KEY)");
		}

		if (!status.anyAvailable) {
			parts.push("\n💡 Tip: Add API keys to .env for real market data");
			parts.push("📖 See REAL_DATA_SETUP.md for instructions");
		}

		return parts.join("\n");
	};

	return (
		<TooltipProvider>
			<Tooltip>
				<TooltipTrigger asChild>
					<Badge
						variant="outline"
						className={`${getStatusColor()} border-2 cursor-help flex items-center gap-2`}
					>
						{getStatusIcon()}
						<span className="text-xs font-medium">{getStatusText()}</span>
					</Badge>
				</TooltipTrigger>
				<TooltipContent className="max-w-xs">
					<div className="space-y-1 text-xs whitespace-pre-line">
						{getDetailedInfo()}
					</div>
				</TooltipContent>
			</Tooltip>
		</TooltipProvider>
	);
}
