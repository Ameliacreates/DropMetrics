/**
 * Commercial-Friendly Analysis Service
 *
 * Uses ONLY APIs that allow commercial/SaaS use:
 * - Perplexity AI (commercial license included)
 * - DataForSEO (optional, commercial-friendly)
 * - RapidAPI marketplaces (commercial-friendly)
 *
 * NO Google Trends (non-commercial restriction)
 */

import { perplexityRequest } from "./perplexityClient";
import type { FeeEstimate } from "./mockAnalysis";

/**
 * Generate market demand analysis using Perplexity AI
 * COMMERCIAL USE: ✅ Allowed
 */
export async function generateDemandAnalysisCommercial(
	productKeyword: string
): Promise<string> {
	const prompt = `As a market research analyst, analyze the dropshipping demand for "${productKeyword}" products.

Provide a comprehensive analysis including:

1. **Market Demand Overview**
   - Estimated monthly search interest (provide realistic estimates based on market data)
   - Current trend direction (growing/stable/declining)
   - Market maturity level

2. **Seasonal Patterns**
   - Peak demand months
   - Low season periods
   - Year-round viability

3. **Market Size & Growth**
   - Estimated global market size (USD)
   - Annual growth rate (CAGR %)
   - Market saturation level

4. **Target Demographics**
   - Primary customer age groups
   - Geographic hotspots
   - Customer preferences

5. **Demand Drivers**
   - Key factors increasing demand
   - Market trends supporting growth
   - Social media influence

Format your response with clear sections and specific data points. Be realistic and data-driven.`;

	try {
		const response = await perplexityRequest({
			userContent: prompt,
			model: "sonar-pro", // Use pro model for better market intelligence
			temperature: 0.2, // Lower temperature for factual analysis
			max_tokens: 2000,
		});

		return response;
	} catch (error) {
		console.error("Perplexity demand analysis failed:", error);
		throw error; // Let caller handle fallback
	}
}

/**
 * Generate competition evaluation using Perplexity AI
 * COMMERCIAL USE: ✅ Allowed
 */
export async function generateCompetitionEvaluationCommercial(
	productCategory: string
): Promise<string> {
	const prompt = `As a dropshipping business consultant, evaluate the competitive landscape for "${productCategory}" products.

Provide detailed analysis on:

1. **Competitor Pricing**
   - Typical price range (minimum to maximum)
   - Average selling price
   - Common pricing strategies

2. **Market Saturation Analysis**
   - Saturation level (Low/Medium/High/Oversaturated)
   - Number of active sellers (estimate)
   - Market entry difficulty rating
   - Barriers to entry

3. **Competitive Advantages Opportunities**
   - Product differentiation strategies
   - Untapped niches or variations
   - Branding opportunities
   - Service differentiators (shipping, support, etc.)

4. **Top Competitors Analysis**
   - Leading brands/sellers
   - Their key strengths
   - Their weaknesses you can exploit
   - Market share distribution

5. **Competition Intensity Factors**
   - Marketing costs (PPC, social ads)
   - Customer acquisition difficulty
   - Brand loyalty levels

Provide specific, actionable insights with realistic market data.`;

	try {
		const response = await perplexityRequest({
			userContent: prompt,
			model: "sonar-pro",
			temperature: 0.2,
			max_tokens: 2000,
		});

		return response;
	} catch (error) {
		console.error("Perplexity competition analysis failed:", error);
		throw error;
	}
}

/**
 * Generate comprehensive business plan using Perplexity AI
 * COMMERCIAL USE: ✅ Allowed
 */
export async function generateBusinessPlanCommercial(
	productName: string
): Promise<{
	executiveSummary: string;
	marketAnalysis: string;
	financialProjections: string;
	operationalStrategy: string;
}> {
	const prompt = `Create a comprehensive dropshipping business plan for "${productName}".

Structure your response with these EXACT sections (use headers):

# EXECUTIVE SUMMARY
- Business concept and value proposition (2-3 paragraphs)
- Target market overview
- Unique selling points
- Key success factors
- Expected outcomes

# MARKET ANALYSIS
- Target customer demographics (age, location, income)
- Market size and growth potential
- Competitive landscape overview
- Market trends and opportunities
- Customer pain points this product solves

# FINANCIAL PROJECTIONS
- Startup costs breakdown (initial inventory, marketing, tools)
- Expected monthly revenue progression (months 1-12)
- Profit margin estimates (realistic percentages)
- Break-even timeline
- Operating expense categories
- Revenue scaling scenarios

# OPERATIONAL STRATEGY
- Supplier sourcing strategy (countries, platforms)
- Order fulfillment process
- Inventory management approach
- Customer service framework
- Marketing channels (specific platforms)
- Social media strategy
- Paid advertising approach
- Customer acquisition cost targets
- Scaling roadmap (3-month, 6-month, 12-month milestones)

Provide realistic, actionable data. Use specific numbers and percentages.`;

	try {
		const response = await perplexityRequest({
			userContent: prompt,
			model: "sonar-reasoning", // Use reasoning model for strategic planning
			temperature: 0.4,
			max_tokens: 3000,
		});

		// Parse the response into sections
		const sections = {
			executiveSummary: extractSection(response, "EXECUTIVE SUMMARY", "MARKET ANALYSIS"),
			marketAnalysis: extractSection(response, "MARKET ANALYSIS", "FINANCIAL PROJECTIONS"),
			financialProjections: extractSection(response, "FINANCIAL PROJECTIONS", "OPERATIONAL STRATEGY"),
			operationalStrategy: extractSection(response, "OPERATIONAL STRATEGY", "END"),
		};

		return sections;
	} catch (error) {
		console.error("Perplexity business plan generation failed:", error);
		throw error;
	}
}

/**
 * Estimate dropshipping fees using AI analysis
 * COMMERCIAL USE: ✅ Allowed
 */
export async function estimateFeesCommercial(
	sellingPrice: number,
	productName?: string
): Promise<FeeEstimate> {
	const prompt = `Estimate realistic dropshipping fees for a product selling at $${sellingPrice}${productName ? ` (product: ${productName})` : ""}.

Provide estimates for:
1. Shipping costs (domestic + international average)
2. Platform/marketplace fees (Shopify/WooCommerce/etc.)
3. Payment processing fees (Stripe/PayPal)
4. Marketing/advertising costs per sale
5. Estimated confidence level (High/Medium/Low)

Format response as JSON with: shippingFee, platformFee, paymentFee, marketingFee, confidence, explanation.`;

	try {
		const response = await perplexityRequest({
			userContent: prompt,
			model: "sonar",
			temperature: 0.1, // Very low for numerical accuracy
			max_tokens: 500,
		});

		// Parse AI response - try JSON first, then fallback to intelligent parsing
		try {
			const parsed = JSON.parse(response);
			return {
				shippingFee: parsed.shippingFee || calculateShippingEstimate(sellingPrice),
				platformFee: parsed.platformFee || sellingPrice * 0.029 + 0.30,
				customerAcquisitionCost: parsed.customerAcquisitionCost || sellingPrice * 0.15,
				creditCardFeePercent: parsed.creditCardFeePercent || 2.9,
				explanation: {
					shipping: parsed.explanation?.shipping || "AI-estimated shipping cost",
					platform: parsed.explanation?.platform || "Standard platform fees (2.9% + $0.30)",
					cac: parsed.explanation?.cac || "Estimated 15% of sale price for customer acquisition",
					creditCard: parsed.explanation?.creditCard || "Standard credit card processing rate",
				},
				confidence: (parsed.confidence?.toLowerCase() as "high" | "medium" | "low") || "medium",
			};
		} catch {
			// Fallback to rule-based estimates if AI response isn't parseable
			return {
				shippingFee: calculateShippingEstimate(sellingPrice),
				platformFee: sellingPrice * 0.029 + 0.30, // Standard Stripe/PayPal rate
				customerAcquisitionCost: sellingPrice * 0.15, // Typical 15% for digital ads
				creditCardFeePercent: 2.9, // Standard rate
				explanation: {
					shipping: "Estimated based on product price range",
					platform: "Standard payment processing fees (2.9% + $0.30)",
					cac: "Industry standard ~15% of sale price for customer acquisition",
					creditCard: "Standard credit card processing fee (2.9%)",
				},
				confidence: "medium",
			};
		}
	} catch (error) {
		console.error("Perplexity fee estimation failed:", error);
		throw error;
	}
}

/**
 * Helper: Extract section from AI response
 */
function extractSection(text: string, startMarker: string, endMarker: string): string {
	const startIndex = text.indexOf(startMarker);
	if (startIndex === -1) return "";

	const contentStart = startIndex + startMarker.length;
	const endIndex = endMarker === "END" ? text.length : text.indexOf(endMarker, contentStart);

	if (endIndex === -1) return text.substring(contentStart).trim();
	return text.substring(contentStart, endIndex).trim();
}

/**
 * Helper: Calculate shipping estimate based on price
 */
function calculateShippingEstimate(price: number): number {
	if (price < 20) return 3.5;
	if (price < 50) return 5.0;
	if (price < 100) return 7.5;
	if (price < 200) return 12.0;
	return 15.0;
}

/**
 * Check if commercial APIs are configured
 */
export function isCommercialApiConfigured(): boolean {
	return !!import.meta.env.VITE_PERPLEXITY_API_KEY;
}

/**
 * Get service status for commercial APIs
 */
export function getCommercialServiceStatus(): {
	configured: boolean;
	provider: string;
	commerciallyLicensed: boolean;
	message: string;
} {
	const configured = isCommercialApiConfigured();

	return {
		configured,
		provider: configured ? "Perplexity AI" : "Mock Data",
		commerciallyLicensed: true, // All our APIs allow commercial use
		message: configured
			? "✅ Using Perplexity AI (Commercial License Included)"
			: "Using mock data. Add VITE_PERPLEXITY_API_KEY to enable real analysis.",
	};
}
