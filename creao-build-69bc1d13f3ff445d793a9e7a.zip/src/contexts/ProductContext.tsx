import { createContext, useContext, useState, type ReactNode } from "react";

interface SelectedProduct {
	productName: string;
	costPrice: number;
	sellingPrice: number;
	shippingCost: number;
	marketingCost: number;
	customerAcquisitionCost: number;
	creditCardFeePercent: number;
}

interface ProductContextType {
	selectedProduct: SelectedProduct | null;
	setSelectedProduct: (product: SelectedProduct | null) => void;
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);

export function ProductProvider({ children }: { children: ReactNode }) {
	const [selectedProduct, setSelectedProduct] = useState<SelectedProduct | null>(null);

	return (
		<ProductContext.Provider value={{ selectedProduct, setSelectedProduct }}>
			{children}
		</ProductContext.Provider>
	);
}

export function useProduct() {
	const context = useContext(ProductContext);
	if (context === undefined) {
		throw new Error("useProduct must be used within a ProductProvider");
	}
	return context;
}
