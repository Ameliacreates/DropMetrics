import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calculator, Save } from "lucide-react";
import { FinancialProjectionORM } from "@/sdk/database/orm/orm_financial_projection";
import { getUserId } from "@/sdk/core/auth";
import { useProduct } from "@/contexts/ProductContext";

interface MonthlyProjection {
	month: number;
	revenue: number;
	expenses: number;
	profit: number;
	cumulativeProfit: number;
}

export function FinancialProjections() {
	const { selectedProduct } = useProduct();
	const [monthlySalesTarget, setMonthlySalesTarget] = useState("");
	const [productPrice, setProductPrice] = useState("");
	const [costPerUnit, setCostPerUnit] = useState("");
	const [growthRate, setGrowthRate] = useState("5");
	const [fixedMonthlyExpenses, setFixedMonthlyExpenses] = useState("");
	const [projections, setProjections] = useState<MonthlyProjection[]>([]);
	const [isSaving, setIsSaving] = useState(false);
	const [saveMessage, setSaveMessage] = useState("");

	// Auto-fill from context
	useEffect(() => {
		if (selectedProduct) {
			setProductPrice(selectedProduct.sellingPrice.toString());
			// Include all per-unit costs: product cost + shipping + platform fees
			const totalUnitCost = selectedProduct.costPrice + selectedProduct.shippingCost + selectedProduct.marketingCost;
			setCostPerUnit(totalUnitCost.toString());
			// Fixed monthly expenses can be set separately if needed
			setFixedMonthlyExpenses("0");
		}
	}, [selectedProduct]);

	const handleGenerate = () => {
		const monthlySales = parseInt(monthlySalesTarget) || 0;
		const price = parseFloat(productPrice) || 0;
		const cost = parseFloat(costPerUnit) || 0;
		const growth = parseFloat(growthRate) / 100;
		const fixedExpenses = parseFloat(fixedMonthlyExpenses) || 0;

		// Get CAC and credit card fee from context if available
		const cacPerUnit = selectedProduct?.customerAcquisitionCost || 0;
		const creditCardFeeRate = selectedProduct?.creditCardFeePercent || 2.9;

		const monthlyData: MonthlyProjection[] = [];
		let cumulativeProfit = 0;

		for (let month = 1; month <= 12; month++) {
			const units = Math.round(monthlySales * Math.pow(1 + growth, month - 1));
			const revenue = units * price;

			// Calculate all per-unit costs
			const productCosts = units * cost;
			const cacCosts = units * cacPerUnit;
			const creditCardFees = revenue * (creditCardFeeRate / 100);

			const totalExpenses = productCosts + cacCosts + creditCardFees + fixedExpenses;
			const profit = revenue - totalExpenses;
			cumulativeProfit += profit;

			monthlyData.push({
				month,
				revenue,
				expenses: totalExpenses,
				profit,
				cumulativeProfit,
			});
		}

		setProjections(monthlyData);
	};

	const handleSave = async () => {
		if (projections.length === 0) {
			setSaveMessage("Generate projections first");
			return;
		}

		setIsSaving(true);
		setSaveMessage("");

		try {
			const orm = FinancialProjectionORM.getInstance();
			const userId = getUserId() || "anonymous";

			await orm.insertFinancialProjection([{
				id: "",
				data_creator: "",
				data_updater: "",
				create_time: "",
				update_time: "",
				product_analysis_id: "",
				monthly_sales_targets: {
					targets: projections.map(p => parseInt(monthlySalesTarget) * Math.pow(1 + parseFloat(growthRate) / 100, p.month - 1))
				},
				growth_assumptions: `${growthRate}% monthly growth`,
				revenue_forecast_12_month: projections.map(p => p.revenue),
				expense_breakdowns: {
					marketing_budget: parseFloat(fixedMonthlyExpenses) * 0.3 || null,
					software_subscriptions: parseFloat(fixedMonthlyExpenses) * 0.2 || null,
					miscellaneous: parseFloat(fixedMonthlyExpenses) * 0.5 || null,
				},
				cash_flow_projections: JSON.stringify(projections.map(p => p.profit)),
				profitability_timeline: JSON.stringify(projections),
			}]);

			setSaveMessage("Projections saved successfully!");
			setTimeout(() => setSaveMessage(""), 3000);
		} catch (error) {
			setSaveMessage("Error: " + (error instanceof Error ? error.message : "Unknown error"));
		} finally {
			setIsSaving(false);
		}
	};

	const totalRevenue = projections.reduce((sum, p) => sum + p.revenue, 0);
	const totalExpenses = projections.reduce((sum, p) => sum + p.expenses, 0);
	const totalProfit = projections.reduce((sum, p) => sum + p.profit, 0);
	const breakEvenMonth = projections.find(p => p.cumulativeProfit >= 0)?.month || 0;

	return (
		<Card>
			<CardHeader>
				<CardTitle>Financial Projections</CardTitle>
				<CardDescription>
					Generate 12-month revenue forecasts, expense breakdowns, and profitability timelines
				</CardDescription>
			</CardHeader>
			<CardContent className="space-y-6">
				<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
					<div className="space-y-2">
						<Label htmlFor="monthly-sales">Monthly Sales Target (units)</Label>
						<Input
							id="monthly-sales"
							type="number"
							placeholder="100"
							value={monthlySalesTarget}
							onChange={(e) => setMonthlySalesTarget(e.target.value)}
						/>
					</div>

					<div className="space-y-2">
						<Label htmlFor="product-price">Product Price ($)</Label>
						<Input
							id="product-price"
							type="number"
							step="0.01"
							placeholder="29.99"
							value={productPrice}
							onChange={(e) => setProductPrice(e.target.value)}
						/>
					</div>

					<div className="space-y-2">
						<Label htmlFor="cost-per-unit">Cost Per Unit ($)</Label>
						<Input
							id="cost-per-unit"
							type="number"
							step="0.01"
							placeholder="15.00"
							value={costPerUnit}
							onChange={(e) => setCostPerUnit(e.target.value)}
						/>
					</div>

					<div className="space-y-2">
						<Label htmlFor="growth-rate">Monthly Growth Rate (%)</Label>
						<Input
							id="growth-rate"
							type="number"
							step="0.1"
							placeholder="5"
							value={growthRate}
							onChange={(e) => setGrowthRate(e.target.value)}
						/>
					</div>

					<div className="space-y-2 md:col-span-2">
						<Label htmlFor="fixed-expenses">Fixed Monthly Expenses ($)</Label>
						<Input
							id="fixed-expenses"
							type="number"
							step="0.01"
							placeholder="500"
							value={fixedMonthlyExpenses}
							onChange={(e) => setFixedMonthlyExpenses(e.target.value)}
						/>
					</div>
				</div>

				<div className="space-y-3">
					<Button onClick={handleGenerate}>
						<Calculator className="size-4 mr-2" />
						Generate Projections
					</Button>

					{selectedProduct && (
						<div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900 rounded-lg p-3">
							<p className="text-xs text-zinc-600 dark:text-zinc-400">
								<span className="font-medium">Note:</span> Projections automatically include Customer Acquisition Cost (${selectedProduct.customerAcquisitionCost.toFixed(2)}/unit) and Credit Card Fees ({selectedProduct.creditCardFeePercent}%) from your saved product data.
							</p>
						</div>
					)}
				</div>

				{projections.length > 0 && (
					<div className="space-y-4 border-t pt-6">
						<div className="grid grid-cols-2 md:grid-cols-4 gap-4">
							<div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-4">
								<p className="text-sm text-zinc-600 dark:text-zinc-400 mb-1">Total Revenue</p>
								<p className="text-xl font-bold text-green-600">${totalRevenue.toFixed(2)}</p>
							</div>

							<div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-4">
								<p className="text-sm text-zinc-600 dark:text-zinc-400 mb-1">Total Expenses</p>
								<p className="text-xl font-bold text-red-600">${totalExpenses.toFixed(2)}</p>
							</div>

							<div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-4">
								<p className="text-sm text-zinc-600 dark:text-zinc-400 mb-1">Net Profit</p>
								<p className={`text-xl font-bold ${totalProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
									${totalProfit.toFixed(2)}
								</p>
							</div>

							<div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-4">
								<p className="text-sm text-zinc-600 dark:text-zinc-400 mb-1">Break-Even Month</p>
								<p className="text-xl font-bold text-zinc-900 dark:text-zinc-50">
									{breakEvenMonth > 0 ? `Month ${breakEvenMonth}` : "N/A"}
								</p>
							</div>
						</div>

						<div className="overflow-x-auto">
							<table className="w-full text-sm">
								<thead className="border-b">
									<tr className="text-left">
										<th className="p-2">Month</th>
										<th className="p-2">Revenue</th>
										<th className="p-2">Expenses</th>
										<th className="p-2">Profit</th>
										<th className="p-2">Cumulative</th>
									</tr>
								</thead>
								<tbody>
									{projections.map((proj) => (
										<tr key={proj.month} className="border-b">
											<td className="p-2 font-medium">Month {proj.month}</td>
											<td className="p-2 text-green-600">${proj.revenue.toFixed(2)}</td>
											<td className="p-2 text-red-600">${proj.expenses.toFixed(2)}</td>
											<td className={`p-2 font-medium ${proj.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
												${proj.profit.toFixed(2)}
											</td>
											<td className={`p-2 font-medium ${proj.cumulativeProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
												${proj.cumulativeProfit.toFixed(2)}
											</td>
										</tr>
									))}
								</tbody>
							</table>
						</div>

						<div className="flex items-center gap-4">
							<Button onClick={handleSave} disabled={isSaving}>
								<Save className="size-4 mr-2" />
								{isSaving ? "Saving..." : "Save Projections"}
							</Button>
							{saveMessage && (
								<Badge variant={saveMessage.includes("Error") ? "destructive" : "default"}>
									{saveMessage}
								</Badge>
							)}
						</div>
					</div>
				)}
			</CardContent>
		</Card>
	);
}
