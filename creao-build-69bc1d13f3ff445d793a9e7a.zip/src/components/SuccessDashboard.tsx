import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, TrendingDown, Target, AlertCircle, CheckCircle2, Download } from "lucide-react";
import { ProductAnalysisORM, type ProductAnalysisModel } from "@/sdk/database/orm/orm_product_analysis";
import { getUserId } from "@/sdk/core/auth";
import { localDB } from "@/lib/localStorageDB";

interface SuccessMetrics {
	competitionScore: number;
	demandScore: number;
	profitScore: number;
	overallScore: number;
	verdict: "High Success Potential" | "Moderate Potential" | "High Risk" | "Not Recommended";
	recommendation: string;
	executiveSummary: string;
}

export function SuccessDashboard() {
	const [isLoading, setIsLoading] = useState(true);
	const [metrics, setMetrics] = useState<SuccessMetrics | null>(null);
	const [latestProduct, setLatestProduct] = useState<ProductAnalysisModel | null>(null);

	useEffect(() => {
		loadAnalysis();
	}, []);

	const loadAnalysis = async () => {
		setIsLoading(true);
		try {
			const userId = getUserId();
			let remoteProducts: ProductAnalysisModel[] = [];

			try {
				const orm = ProductAnalysisORM.getInstance();
				remoteProducts = userId
					? await orm.getProductAnalysisByUserId(userId)
					: await orm.getAllProductAnalysis();
			} catch {
				// Remote unavailable — use local only
			}

			// Merge remote + local, deduplicated by id
			const localProducts = userId
				? localDB.getByUserId(userId)
				: localDB.getAll();
			const remoteIds = new Set(remoteProducts.map((p) => p.id));
			const allProducts = [
				...remoteProducts,
				...localProducts.filter((p) => !remoteIds.has(p.id)),
			];

			if (allProducts.length > 0) {
				// Get the most recent product
				const latest = allProducts[allProducts.length - 1];
				setLatestProduct(latest);

				// Calculate success metrics
				const calculatedMetrics = calculateSuccessMetrics(latest);
				setMetrics(calculatedMetrics);
			}
		} catch (error) {
			console.error("Error loading analysis:", error);
		} finally {
			setIsLoading(false);
		}
	};

	const calculateSuccessMetrics = (product: ProductAnalysisModel): SuccessMetrics => {
		// Competition Score (0-100): Lower competition = higher score
		// Assuming we don't have direct competition data, we'll use profit margin as a proxy
		const competitionScore = Math.min(100, Math.max(0, 70 + (product.profit_margin - 30)));

		// Demand Score (0-100): Based on potential sales volume
		// Higher ROI suggests better demand potential
		const demandScore = Math.min(100, Math.max(0, 50 + product.roi / 2));

		// Profit Score (0-100): Based on profit margin and ROI
		const profitScore = Math.min(100, Math.max(0, (product.profit_margin * 0.6 + product.roi * 0.4)));

		// Overall Success Score (weighted average)
		const overallScore = Math.round(
			competitionScore * 0.3 + demandScore * 0.3 + profitScore * 0.4
		);

		// Determine verdict
		let verdict: SuccessMetrics["verdict"];
		if (overallScore >= 75) {
			verdict = "High Success Potential";
		} else if (overallScore >= 50) {
			verdict = "Moderate Potential";
		} else if (overallScore >= 30) {
			verdict = "High Risk";
		} else {
			verdict = "Not Recommended";
		}

		// Generate recommendation
		const recommendation = generateRecommendation(
			product,
			competitionScore,
			demandScore,
			profitScore
		);

		// Generate executive summary
		const executiveSummary = generateExecutiveSummary(
			product,
			overallScore,
			verdict
		);

		return {
			competitionScore: Math.round(competitionScore),
			demandScore: Math.round(demandScore),
			profitScore: Math.round(profitScore),
			overallScore,
			verdict,
			recommendation,
			executiveSummary,
		};
	};

	const generateRecommendation = (
		product: ProductAnalysisModel,
		competition: number,
		demand: number,
		profit: number
	): string => {
		const improvements: string[] = [];

		if (competition < 60) {
			improvements.push(
				"Focus on differentiation - emphasize unique features, superior quality, or exceptional customer service to stand out from competitors"
			);
		}

		if (demand < 60) {
			improvements.push(
				"Boost marketing efforts - invest in targeted social media advertising, influencer partnerships, and SEO optimization to increase product visibility"
			);
		}

		if (profit < 60) {
			improvements.push(
				"Optimize pricing strategy - consider negotiating better supplier rates, reducing shipping costs, or implementing tiered pricing to improve margins"
			);
		}

		if (product.profit_margin < 30) {
			improvements.push(
				"Increase profit margins - aim for at least 30-40% margins by sourcing from cheaper suppliers or adding value-added services"
			);
		}

		if (improvements.length === 0) {
			return "Your product shows strong potential across all metrics. Focus on scaling your operations, building brand loyalty, and expanding your marketing reach to maximize success.";
		}

		return improvements.join(". ");
	};

	const generateExecutiveSummary = (
		product: ProductAnalysisModel,
		score: number,
		verdict: string
	): string => {
		const profitPerUnit = product.selling_price - product.cost_price;
		const marginDescription =
			product.profit_margin >= 40
				? "excellent"
				: product.profit_margin >= 30
					? "healthy"
					: product.profit_margin >= 20
						? "moderate"
						: "concerning";

		return `Product "${product.product_name}" demonstrates ${verdict.toLowerCase()} with an overall success score of ${score}/100. Financial analysis reveals a ${marginDescription} profit margin of ${product.profit_margin.toFixed(1)}% ($${profitPerUnit.toFixed(2)} per unit) and ROI of ${product.roi.toFixed(1)}%. To reach break-even, ${product.break_even_units} units must be sold. ${score >= 75 ? "This product is well-positioned for market entry with strong fundamentals across competition, demand, and profitability metrics." : score >= 50 ? "While this product shows promise, strategic improvements in marketing and cost optimization could significantly enhance success potential." : "This product faces significant challenges and requires substantial improvements before market entry is recommended."}`;
	};

	const getMeterColor = (score: number): string => {
		if (score >= 75) return "text-success";
		if (score >= 50) return "text-warning";
		return "text-danger";
	};

	const getMeterPosition = (score: number): string => {
		// Convert 0-100 score to 0-100% position
		return `${score}%`;
	};

	const getScoreColor = (score: number): string => {
		if (score >= 75) return "bg-success-light/20 text-success border-success";
		if (score >= 50) return "bg-warning-light/20 text-warning border-warning";
		return "bg-danger-light/20 text-danger border-danger";
	};

	const getScoreColorInline = (score: number): React.CSSProperties => {
		if (score >= 75) {
			return {
				backgroundColor: 'rgba(16, 185, 129, 0.2)',
				color: 'var(--success)',
				borderColor: 'var(--success)'
			};
		}
		if (score >= 50) {
			return {
				backgroundColor: 'rgba(245, 158, 11, 0.2)',
				color: 'var(--warning)',
				borderColor: 'var(--warning)'
			};
		}
		return {
			backgroundColor: 'rgba(239, 68, 68, 0.2)',
			color: 'var(--danger)',
			borderColor: 'var(--danger)'
		};
	};

	const handleDownloadReport = () => {
		if (!latestProduct || !metrics) return;

		const report = `DROPMETRICS SUCCESS DASHBOARD REPORT
${new Date().toLocaleDateString()}

===========================================
EXECUTIVE SUMMARY
===========================================

${metrics.executiveSummary}

===========================================
SUCCESS METRICS
===========================================

Overall Success Score: ${metrics.overallScore}/100
Verdict: ${metrics.verdict}

Triple-Check Analysis:
• Competition Score: ${metrics.competitionScore}/100
• Demand Score: ${metrics.demandScore}/100
• Profit Score: ${metrics.profitScore}/100

===========================================
PRODUCT DETAILS
===========================================

Product Name: ${latestProduct.product_name}
Cost Price: $${latestProduct.cost_price.toFixed(2)}
Selling Price: $${latestProduct.selling_price.toFixed(2)}
Profit Margin: ${latestProduct.profit_margin.toFixed(2)}%
ROI: ${latestProduct.roi.toFixed(2)}%
Break-Even Units: ${latestProduct.break_even_units}

===========================================
RECOMMENDATIONS
===========================================

${metrics.recommendation}

===========================================
Generated by Dropmetrics
`;

		const blob = new Blob([report], { type: "text/plain" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `success-report-${latestProduct.product_name.toLowerCase().replace(/\s+/g, "-")}.txt`;
		a.click();
		URL.revokeObjectURL(url);
	};

	if (isLoading) {
		return (
			<Card>
				<CardHeader>
					<CardTitle>Success Dashboard</CardTitle>
					<CardDescription>Executive summary of your product analysis</CardDescription>
				</CardHeader>
				<CardContent>
					<div className="text-center py-8 text-zinc-600 dark:text-zinc-400">
						Loading analysis...
					</div>
				</CardContent>
			</Card>
		);
	}

	if (!latestProduct || !metrics) {
		return (
			<Card>
				<CardHeader>
					<CardTitle>Success Dashboard</CardTitle>
					<CardDescription>Executive summary of your product analysis</CardDescription>
				</CardHeader>
				<CardContent>
					<div className="text-center py-8 text-zinc-600 dark:text-zinc-400">
						<AlertCircle className="size-12 mx-auto mb-4 text-zinc-400" />
						<p className="mb-2">No product analysis found</p>
						<p className="text-sm">
							Use the Calculator tab to analyze your first product
						</p>
					</div>
				</CardContent>
			</Card>
		);
	}

	return (
		<Card>
			<CardHeader>
				<div className="flex items-center justify-between">
					<div>
						<CardTitle>Success Dashboard</CardTitle>
						<CardDescription>
							Comprehensive analysis for: <span className="font-semibold">{latestProduct.product_name}</span>
						</CardDescription>
					</div>
					<Button onClick={handleDownloadReport} variant="outline" size="sm">
						<Download className="size-4 mr-2" />
						Download Report
					</Button>
				</div>
			</CardHeader>
			<CardContent className="space-y-6">
				{/* Success Meter */}
				<div className="space-y-4">
					<div className="flex items-center justify-between">
						<h3 className="text-lg font-semibold">Overall Success Score</h3>
						<Badge
							variant="outline"
							className="border-2"
							style={getScoreColorInline(metrics.overallScore)}
						>
							{metrics.overallScore}/100
						</Badge>
					</div>

					{/* Gradient Meter */}
					<div className="relative">
						<div
							className="h-8 rounded-full shadow-inner"
							style={{
								background: `linear-gradient(to right, var(--danger), var(--warning), var(--success))`
							}}
						/>
						<div
							className="absolute top-0 h-8 flex items-center transition-all duration-500"
							style={{ left: getMeterPosition(metrics.overallScore) }}
						>
							<div className="relative -ml-3">
								<div
									className="w-6 h-6 rotate-45 bg-white dark:bg-zinc-800 border-2 shadow-lg"
									style={{
										borderColor: metrics.overallScore >= 75 ? 'var(--success)' : metrics.overallScore >= 50 ? 'var(--warning)' : 'var(--danger)'
									}}
								/>
								<div className="absolute -top-8 left-1/2 -translate-x-1/2 whitespace-nowrap">
									<Badge
										className="border-2"
										style={getScoreColorInline(metrics.overallScore)}
									>
										{metrics.overallScore}
									</Badge>
								</div>
							</div>
						</div>
					</div>

					<div className="flex justify-between text-xs" style={{ color: 'var(--neutral)' }}>
						<span>High Risk</span>
						<span>Moderate</span>
						<span>High Success</span>
					</div>
				</div>

				{/* Verdict */}
				<div
					className="rounded-lg p-6 border-2"
					style={getScoreColorInline(metrics.overallScore)}
				>
					<div className="flex items-start gap-3">
						{metrics.overallScore >= 75 ? (
							<CheckCircle2 className="size-6 flex-shrink-0 mt-0.5" />
						) : metrics.overallScore >= 50 ? (
							<TrendingUp className="size-6 flex-shrink-0 mt-0.5" />
						) : (
							<TrendingDown className="size-6 flex-shrink-0 mt-0.5" />
						)}
						<div>
							<h3 className="text-xl font-bold mb-2">{metrics.verdict}</h3>
							<p className="text-sm leading-relaxed">{metrics.executiveSummary}</p>
						</div>
					</div>
				</div>

				{/* Triple Check Scores */}
				<div>
					<h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
						<Target className="size-5" />
						Triple-Check Analysis
					</h3>
					<div className="grid grid-cols-1 md:grid-cols-3 gap-4">
						<div className="border-2 rounded-lg p-4" style={getScoreColorInline(metrics.competitionScore)}>
							<p className="text-xs font-medium uppercase tracking-wide mb-2 opacity-75">
								Competition
							</p>
							<p className="text-3xl font-bold mb-1">{metrics.competitionScore}</p>
							<p className="text-xs opacity-75">out of 100</p>
							<div className="mt-3 h-2 bg-white/50 dark:bg-black/20 rounded-full overflow-hidden">
								<div
									className="h-full bg-current transition-all"
									style={{ width: `${metrics.competitionScore}%` }}
								/>
							</div>
						</div>

						<div className="border-2 rounded-lg p-4" style={getScoreColorInline(metrics.demandScore)}>
							<p className="text-xs font-medium uppercase tracking-wide mb-2 opacity-75">
								Demand
							</p>
							<p className="text-3xl font-bold mb-1">{metrics.demandScore}</p>
							<p className="text-xs opacity-75">out of 100</p>
							<div className="mt-3 h-2 bg-white/50 dark:bg-black/20 rounded-full overflow-hidden">
								<div
									className="h-full bg-current transition-all"
									style={{ width: `${metrics.demandScore}%` }}
								/>
							</div>
						</div>

						<div className="border-2 rounded-lg p-4" style={getScoreColorInline(metrics.profitScore)}>
							<p className="text-xs font-medium uppercase tracking-wide mb-2 opacity-75">
								Profit
							</p>
							<p className="text-3xl font-bold mb-1">{metrics.profitScore}</p>
							<p className="text-xs opacity-75">out of 100</p>
							<div className="mt-3 h-2 bg-white/50 dark:bg-black/20 rounded-full overflow-hidden">
								<div
									className="h-full bg-current transition-all"
									style={{ width: `${metrics.profitScore}%` }}
								/>
							</div>
						</div>
					</div>
				</div>

				{/* Recommendations */}
				<div
					className="rounded-lg p-6 border-2"
					style={{
						backgroundColor: 'rgba(102, 126, 234, 0.1)',
						borderColor: 'var(--primary)'
					}}
				>
					<h3 className="text-lg font-semibold mb-3 flex items-center gap-2" style={{ color: 'var(--primary)' }}>
						<Target className="size-5" />
						Recommendations for Competitive Success
					</h3>
					<p className="text-sm leading-relaxed" style={{ color: 'var(--neutral)' }}>
						{metrics.recommendation}
					</p>
				</div>

				{/* Key Metrics Summary */}
				<div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t">
					<div className="text-center">
						<p className="text-xs text-zinc-500 dark:text-zinc-400 mb-1">Profit Margin</p>
						<p className="text-2xl font-bold text-zinc-900 dark:text-zinc-100">
							{latestProduct.profit_margin.toFixed(1)}%
						</p>
					</div>
					<div className="text-center">
						<p className="text-xs text-zinc-500 dark:text-zinc-400 mb-1">ROI</p>
						<p className="text-2xl font-bold text-zinc-900 dark:text-zinc-100">
							{latestProduct.roi.toFixed(1)}%
						</p>
					</div>
					<div className="text-center">
						<p className="text-xs text-zinc-500 dark:text-zinc-400 mb-1">Break-Even</p>
						<p className="text-2xl font-bold text-zinc-900 dark:text-zinc-100">
							{latestProduct.break_even_units}
						</p>
					</div>
					<div className="text-center">
						<p className="text-xs text-zinc-500 dark:text-zinc-400 mb-1">Profit/Unit</p>
						<p className="text-2xl font-bold text-zinc-900 dark:text-zinc-100">
							${(latestProduct.selling_price - latestProduct.cost_price).toFixed(2)}
						</p>
					</div>
				</div>
			</CardContent>
		</Card>
	);
}
