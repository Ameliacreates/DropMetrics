import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Download, FileText, Save, Loader2, Sparkles } from "lucide-react";
import { BusinessPlanORM } from "@/sdk/database/orm/orm_business_plan";
import { getUserId } from "@/sdk/core/auth";
import { request as perplexitySearch } from "@/sdk/mcp-clients/6875e6198345ff1a8579cd8a/PERPLEXITYAI_PERPLEXITY_AI_SEARCH";
import { useApiMode } from "@/lib/apiMode";
import { generateBusinessPlan } from "@/lib/analysisService";
import { DataBubbles } from "@/components/DataBubbles";
import { parseBusinessPlanComplete } from "@/lib/analysisParser";
import { useProduct } from "@/contexts/ProductContext";

export function BusinessPlanExport() {
	const { useMockData } = useApiMode();
	const { selectedProduct } = useProduct();
	const [productName, setProductName] = useState("");
	const [isGenerating, setIsGenerating] = useState(false);
	const [isSaving, setIsSaving] = useState(false);
	const [saveMessage, setSaveMessage] = useState("");
	const [showFullAnalysis, setShowFullAnalysis] = useState(false);

	// Auto-fill product name from context
	useEffect(() => {
		if (selectedProduct?.productName) {
			setProductName(selectedProduct.productName);
		}
	}, [selectedProduct]);
	const [businessPlan, setBusinessPlan] = useState({
		executiveSummary: "",
		marketAnalysis: "",
		financialProjections: "",
		operationalStrategy: "",
	});

	const handleGenerate = async () => {
		if (!productName.trim()) return;

		setIsGenerating(true);

		try {
			let sections: {
				executiveSummary: string;
				marketAnalysis: string;
				financialProjections: string;
				operationalStrategy: string;
			};

			if (useMockData) {
				// Use mock data
				sections = await generateBusinessPlan(productName);
			} else {
				// Use real API
				const response = await perplexitySearch({
					userContent: `Create a comprehensive dropshipping business plan for "${productName}". Include:

1. EXECUTIVE SUMMARY (2-3 paragraphs)
- Business concept and value proposition
- Target market overview
- Key success factors

2. MARKET ANALYSIS (detailed)
- Target customer demographics
- Market size and growth potential
- Competitive landscape
- Market trends and opportunities

3. FINANCIAL PROJECTIONS (realistic estimates)
- Startup costs breakdown
- Expected monthly revenue (months 1-12)
- Operating expenses
- Break-even analysis
- Profit margins

4. OPERATIONAL STRATEGY
- Supplier sourcing strategy
- Order fulfillment process
- Customer service approach
- Marketing and customer acquisition channels
- Scaling strategy

Format each section with clear headers.`,
					model: "sonar-pro",
					temperature: 0.5,
					max_tokens: 2000,
				});

				const content = response.choices[0]?.message?.content || "";
				sections = parsePlanSections(content);
			}

			setBusinessPlan(sections);
		} catch (error) {
			console.error("Business plan generation error:", error);
			setSaveMessage("Error generating plan: " + (error instanceof Error ? error.message : "Unknown error"));
		} finally {
			setIsGenerating(false);
		}
	};

	const parsePlanSections = (content: string) => {
		const sections = {
			executiveSummary: extractSection(content, "EXECUTIVE SUMMARY", "MARKET ANALYSIS"),
			marketAnalysis: extractSection(content, "MARKET ANALYSIS", "FINANCIAL PROJECTIONS"),
			financialProjections: extractSection(content, "FINANCIAL PROJECTIONS", "OPERATIONAL STRATEGY"),
			operationalStrategy: extractSection(content, "OPERATIONAL STRATEGY", "END"),
		};

		return sections;
	};

	const extractSection = (text: string, startMarker: string, endMarker: string): string => {
		const startIndex = text.indexOf(startMarker);
		if (startIndex === -1) return "";

		const contentStart = startIndex + startMarker.length;
		const endIndex = endMarker === "END" ? text.length : text.indexOf(endMarker, contentStart);

		if (endIndex === -1) return text.substring(contentStart).trim();
		return text.substring(contentStart, endIndex).trim();
	};

	const handleSave = async () => {
		if (!businessPlan.executiveSummary) {
			setSaveMessage("Generate a business plan first");
			return;
		}

		setIsSaving(true);
		setSaveMessage("");

		try {
			const orm = BusinessPlanORM.getInstance();
			const userId = getUserId() || "anonymous";

			const fullDocument = `# Business Plan: ${productName}

## Executive Summary
${businessPlan.executiveSummary}

## Market Analysis
${businessPlan.marketAnalysis}

## Financial Projections
${businessPlan.financialProjections}

## Operational Strategy
${businessPlan.operationalStrategy}`;

			await orm.insertBusinessPlan([{
				id: "",
				data_creator: "",
				data_updater: "",
				create_time: "",
				update_time: "",
				product_analysis_id: "",
				executive_summary: businessPlan.executiveSummary,
				market_analysis_content: businessPlan.marketAnalysis,
				financial_summary: businessPlan.financialProjections,
				operational_strategy: businessPlan.operationalStrategy,
				generated_content: fullDocument,
			}]);

			setSaveMessage("Business plan saved successfully!");
			setTimeout(() => setSaveMessage(""), 3000);
		} catch (error) {
			setSaveMessage("Error: " + (error instanceof Error ? error.message : "Unknown error"));
		} finally {
			setIsSaving(false);
		}
	};

	const handleDownload = () => {
		const fullDocument = `# Business Plan: ${productName}

## Executive Summary
${businessPlan.executiveSummary}

## Market Analysis
${businessPlan.marketAnalysis}

## Financial Projections
${businessPlan.financialProjections}

## Operational Strategy
${businessPlan.operationalStrategy}

---
Generated by Dropmetrics
`;

		const blob = new Blob([fullDocument], { type: "text/plain" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `business-plan-${productName.toLowerCase().replace(/\s+/g, "-")}.txt`;
		a.click();
		URL.revokeObjectURL(url);
	};

	const fullPlanText = businessPlan.executiveSummary
		? `${businessPlan.executiveSummary}\n\n${businessPlan.marketAnalysis}\n\n${businessPlan.financialProjections}\n\n${businessPlan.operationalStrategy}`
		: "";
	const dataBubbles = fullPlanText ? parseBusinessPlanComplete(fullPlanText) : [];

	return (
		<Card>
			<CardHeader>
				<CardTitle>Business Plan Export</CardTitle>
				<CardDescription>
					Generate comprehensive business plans with AI and export as documents
				</CardDescription>
			</CardHeader>
			<CardContent className="space-y-6">
				<div className="flex gap-4">
					<div className="flex-1 space-y-2">
						<Label htmlFor="plan-product-name">Product Name</Label>
						<Input
							id="plan-product-name"
							placeholder="e.g., Smart Water Bottle"
							value={productName}
							onChange={(e) => setProductName(e.target.value)}
						/>
					</div>
					<div className="flex items-end">
						<Button onClick={handleGenerate} disabled={isGenerating || !productName.trim()}>
							{isGenerating ? (
								<>
									<Loader2 className="size-4 mr-2 animate-spin" />
									Generating...
								</>
							) : (
								<>
									<FileText className="size-4 mr-2" />
									Generate Plan
								</>
							)}
						</Button>
					</div>
				</div>

				{businessPlan.executiveSummary && (
					<div className="space-y-6 border-t pt-6">
						{/* Simplified Data Bubbles */}
						<div className="space-y-4">
							<div className="flex items-center justify-between">
								<div className="flex items-center gap-2">
									<Sparkles className="size-5 text-green-600 dark:text-green-400" />
									<h3 className="text-lg font-semibold">Business Plan Highlights</h3>
									<Badge variant="secondary" className="text-xs">Simplified View</Badge>
								</div>
								<Button
									variant="outline"
									size="sm"
									onClick={() => setShowFullAnalysis(!showFullAnalysis)}
								>
									<FileText className="size-4 mr-2" />
									{showFullAnalysis ? "Hide" : "Show"} Full Plan
								</Button>
							</div>

							{dataBubbles.length > 0 ? (
								<DataBubbles bubbles={dataBubbles} />
							) : (
								<p className="text-sm text-zinc-500 dark:text-zinc-400 italic">
									No simplified data available. Click "Show Full Plan" for details.
								</p>
							)}
						</div>

						{/* Full Business Plan (Collapsible) */}
						{showFullAnalysis && (
							<div className="space-y-4 border-t pt-6">
								<div className="flex items-center gap-2">
									<FileText className="size-5 text-zinc-600 dark:text-zinc-400" />
									<h3 className="text-lg font-semibold">Complete Business Plan</h3>
									<Badge className="text-xs">Editable Sections</Badge>
								</div>

								<div className="space-y-4">
									<div>
										<Label>Executive Summary</Label>
										<Textarea
											value={businessPlan.executiveSummary}
											onChange={(e) => setBusinessPlan({...businessPlan, executiveSummary: e.target.value})}
											rows={4}
											className="mt-2"
										/>
									</div>

									<div>
										<Label>Market Analysis</Label>
										<Textarea
											value={businessPlan.marketAnalysis}
											onChange={(e) => setBusinessPlan({...businessPlan, marketAnalysis: e.target.value})}
											rows={6}
											className="mt-2"
										/>
									</div>

									<div>
										<Label>Financial Projections</Label>
										<Textarea
											value={businessPlan.financialProjections}
											onChange={(e) => setBusinessPlan({...businessPlan, financialProjections: e.target.value})}
											rows={6}
											className="mt-2"
										/>
									</div>

									<div>
										<Label>Operational Strategy</Label>
										<Textarea
											value={businessPlan.operationalStrategy}
											onChange={(e) => setBusinessPlan({...businessPlan, operationalStrategy: e.target.value})}
											rows={6}
											className="mt-2"
										/>
									</div>
								</div>
							</div>
						)}

						<div className="flex items-center gap-4 border-t pt-4">
							<Button onClick={handleSave} disabled={isSaving}>
								<Save className="size-4 mr-2" />
								{isSaving ? "Saving..." : "Save Plan"}
							</Button>
							<Button onClick={handleDownload} variant="outline">
								<Download className="size-4 mr-2" />
								Download as Text
							</Button>
							{saveMessage && (
								<Badge variant={saveMessage.includes("Error") ? "destructive" : "default"}>
									{saveMessage}
								</Badge>
							)}
						</div>
					</div>
				)}
			</CardContent>
		</Card>
	);
}
