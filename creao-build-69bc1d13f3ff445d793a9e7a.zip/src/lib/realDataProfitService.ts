/**
 * Real Data Profit Calculator Service
 * Integrates Google Trends and AliExpress data for accurate profit predictions
 */

import {
	fetchGoogleTrends,
	calculateDemandScore,
	isGoogleTrendsConfigured,
	type TrendsData,
} from "./googleTrendsService";

import {
	searchAliExpressProducts,
	calculateOptimalPricing,
	isAliExpressConfigured,
	type ProductPricingData,
} from "./aliexpressService";

export interface EnhancedProductData {
	productName: string;
	// Pricing data from AliExpress
	pricing: {
		suggestedCostPrice: number;
		suggestedSellingPrice: number;
		minPrice: number;
		maxPrice: number;
		averageShipping: number;
		priceRange: string;
		confidence: number;
	};
	// Market demand from Google Trends
	demand: {
		score: number; // 0-100
		trend: "rising" | "stable" | "declining";
		averageInterest: number;
		relatedSearches: string[];
		seasonality: string[];
		confidence: number;
	};
	// Competition analysis
	competition: {
		competitorCount: number;
		saturationLevel: "low" | "medium" | "high" | "very-high";
		topCompetitorPrice: number;
	};
	// Recommendations
	recommendations: {
		shouldProceed: boolean;
		confidence: number;
		reasoning: string[];
		suggestedActions: string[];
	};
	dataSource: "real" | "mock" | "hybrid";
}

/**
 * Fetch real product data from Google Trends and AliExpress
 */
export async function fetchRealProductData(
	productName: string
): Promise<EnhancedProductData> {
	const hasGoogleTrends = isGoogleTrendsConfigured();
	const hasAliExpress = isAliExpressConfigured();

	// Fetch data in parallel
	const [trendsData, pricingData] = await Promise.all([
		// Always try Google Trends (even mock version provides value)
		fetchGoogleTrends(productName).catch(() => null as TrendsData | null),
		// Always try AliExpress (even mock version provides value)
		searchAliExpressProducts(productName).catch(() => null as ProductPricingData | null),
	]);

	// Determine data source
	let dataSource: "real" | "mock" | "hybrid" = "mock";
	if (hasGoogleTrends && hasAliExpress) {
		dataSource = "real";
	} else if (hasGoogleTrends || hasAliExpress) {
		dataSource = "hybrid";
	}

	// Calculate optimal pricing
	const optimalPricing = pricingData
		? calculateOptimalPricing(pricingData)
		: {
				costPrice: 15,
				suggestedSellingPrice: 45,
				minSellingPrice: 30,
				maxSellingPrice: 75,
				estimatedMargin: 67,
		  };

	// Calculate demand score
	const demandScore = trendsData ? calculateDemandScore(trendsData) : 65;

	// Determine saturation level
	const competitorCount = pricingData ? pricingData.competitorCount : 150;
	let saturationLevel: "low" | "medium" | "high" | "very-high" = "medium";
	if (competitorCount < 50) saturationLevel = "low";
	else if (competitorCount < 200) saturationLevel = "medium";
	else if (competitorCount < 500) saturationLevel = "high";
	else saturationLevel = "very-high";

	// Generate recommendations
	const recommendations = generateRecommendations(
		demandScore,
		optimalPricing.estimatedMargin,
		saturationLevel,
		trendsData ? trendsData.trend : "stable"
	);

	return {
		productName,
		pricing: {
			suggestedCostPrice: optimalPricing.costPrice,
			suggestedSellingPrice: optimalPricing.suggestedSellingPrice,
			minPrice: pricingData ? pricingData.minPrice : optimalPricing.minSellingPrice,
			maxPrice: pricingData ? pricingData.maxPrice : optimalPricing.maxSellingPrice,
			averageShipping: pricingData ? pricingData.averageShipping : 3.5,
			priceRange: `$${pricingData ? pricingData.minPrice : optimalPricing.minSellingPrice} - $${pricingData ? pricingData.maxPrice : optimalPricing.maxSellingPrice}`,
			confidence: hasAliExpress ? 90 : 70,
		},
		demand: {
			score: demandScore,
			trend: trendsData ? trendsData.trend : "stable",
			averageInterest: trendsData ? trendsData.averageInterest : 50,
			relatedSearches: trendsData ? trendsData.relatedQueries : [],
			seasonality: trendsData ? trendsData.seasonalPeaks : ["November", "December"],
			confidence: hasGoogleTrends ? 85 : 65,
		},
		competition: {
			competitorCount,
			saturationLevel,
			topCompetitorPrice: pricingData ? pricingData.averagePrice : optimalPricing.costPrice,
		},
		recommendations,
		dataSource,
	};
}

/**
 * Generate business recommendations based on data
 */
function generateRecommendations(
	demandScore: number,
	profitMargin: number,
	saturationLevel: string,
	trend: string
): EnhancedProductData["recommendations"] {
	const reasoning: string[] = [];
	const suggestedActions: string[] = [];
	let shouldProceed = false;
	let confidence = 50;

	// Evaluate demand
	if (demandScore >= 70) {
		reasoning.push("Strong market demand detected");
		confidence += 20;
	} else if (demandScore >= 50) {
		reasoning.push("Moderate market demand");
		confidence += 10;
	} else {
		reasoning.push("Low market demand - may require heavy marketing");
		suggestedActions.push("Consider niche targeting or influencer partnerships");
	}

	// Evaluate profit margin
	if (profitMargin >= 60) {
		reasoning.push("Excellent profit margins (>60%)");
		confidence += 15;
	} else if (profitMargin >= 40) {
		reasoning.push("Good profit margins (40-60%)");
		confidence += 10;
	} else {
		reasoning.push("Thin profit margins - limited room for marketing spend");
		suggestedActions.push("Negotiate better supplier pricing or find alternative sources");
	}

	// Evaluate competition
	if (saturationLevel === "low") {
		reasoning.push("Low competition - great opportunity");
		confidence += 15;
	} else if (saturationLevel === "medium") {
		reasoning.push("Moderate competition - differentiation important");
		suggestedActions.push("Focus on unique branding and superior customer service");
	} else {
		reasoning.push("High competition - difficult to stand out");
		suggestedActions.push("Consider finding a less saturated niche");
		confidence -= 10;
	}

	// Evaluate trend
	if (trend === "rising") {
		reasoning.push("Growing market trend - act quickly");
		confidence += 10;
		suggestedActions.push("Launch soon to capitalize on rising demand");
	} else if (trend === "declining") {
		reasoning.push("Declining market interest");
		confidence -= 15;
		suggestedActions.push("Consider alternative products with better trends");
	}

	// Final decision
	shouldProceed = confidence >= 60;

	if (!suggestedActions.length) {
		suggestedActions.push(
			"Product shows promise - focus on quality listings and fast shipping"
		);
	}

	return {
		shouldProceed,
		confidence: Math.min(100, Math.max(0, confidence)),
		reasoning,
		suggestedActions,
	};
}

/**
 * Quick pricing estimate (faster, less detailed)
 */
export async function quickPriceEstimate(
	productName: string
): Promise<{
	costPrice: number;
	sellingPrice: number;
	shipping: number;
}> {
	try {
		const pricingData = await searchAliExpressProducts(productName, 3);
		const optimal = calculateOptimalPricing(pricingData);

		return {
			costPrice: optimal.costPrice,
			sellingPrice: optimal.suggestedSellingPrice,
			shipping: pricingData.averageShipping,
		};
	} catch (error) {
		console.error("Quick price estimate failed:", error);
		// Fallback to simple estimation
		return {
			costPrice: 15,
			sellingPrice: 45,
			shipping: 3.5,
		};
	}
}

/**
 * Check if real data services are available
 */
export function isRealDataAvailable(): {
	googleTrends: boolean;
	aliexpress: boolean;
	anyAvailable: boolean;
	message: string;
} {
	const googleTrends = isGoogleTrendsConfigured();
	const aliexpress = isAliExpressConfigured();
	const anyAvailable = googleTrends || aliexpress;

	let message = "";
	if (!anyAvailable) {
		message = "Using mock data. Configure API keys for real market data.";
	} else if (googleTrends && aliexpress) {
		message = "All real data sources configured and active!";
	} else if (googleTrends) {
		message = "Google Trends active. Add AliExpress API for pricing data.";
	} else {
		message = "AliExpress active. Add Google Trends API for demand data.";
	}

	return {
		googleTrends,
		aliexpress,
		anyAvailable,
		message,
	};
}
