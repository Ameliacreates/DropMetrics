/**
 * Secure Perplexity AI Client
 *
 * This module provides a safe wrapper around the Perplexity AI API.
 * It handles API key validation and error handling.
 */

import { apiConfig } from "./apiConfig";

interface PerplexityRequest {
	userContent: string;
	model?: string;
	temperature?: number;
	max_tokens?: number;
}

interface PerplexityResponse {
	choices: Array<{
		message: {
			content: string;
		};
	}>;
}

/**
 * Make a request to Perplexity AI API
 * Falls back to mock data if API key is not configured
 */
export async function perplexityRequest(params: PerplexityRequest): Promise<string> {
	// If no API key is configured, throw an error to trigger mock data fallback
	if (!apiConfig.isConfigured) {
		throw new Error("API_NOT_CONFIGURED");
	}

	try {
		const response = await fetch("https://api.perplexity.ai/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"Authorization": `Bearer ${apiConfig.perplexityApiKey}`,
			},
			body: JSON.stringify({
				model: params.model || apiConfig.perplexityModel,
				messages: [
					{
						role: "user",
						content: params.userContent,
					},
				],
				temperature: params.temperature ?? 0.3,
				max_tokens: params.max_tokens ?? 1000,
			}),
		});

		if (!response.ok) {
			const errorText = await response.text();
			console.error("Perplexity API error:", errorText);
			throw new Error(`API_ERROR: ${response.status}`);
		}

		const data: PerplexityResponse = await response.json();
		return data.choices[0]?.message?.content || "No response from API";
	} catch (error) {
		console.error("Perplexity API request failed:", error);
		throw error;
	}
}

/**
 * Check if the API is available and working
 */
export async function testApiConnection(): Promise<boolean> {
	if (!apiConfig.isConfigured) {
		return false;
	}

	try {
		await perplexityRequest({
			userContent: "Test connection. Reply with 'OK'.",
			max_tokens: 10,
		});
		return true;
	} catch {
		return false;
	}
}
