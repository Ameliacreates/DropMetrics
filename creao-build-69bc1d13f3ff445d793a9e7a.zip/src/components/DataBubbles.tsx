import { type DataBubble, getBubbleColorClasses } from "@/lib/analysisParser";

interface DataBubblesProps {
	bubbles: DataBubble[];
}

export function DataBubbles({ bubbles }: DataBubblesProps) {
	if (bubbles.length === 0) {
		return null;
	}

	return (
		<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
			{bubbles.map((bubble, index) => {
				const colors = getBubbleColorClasses(bubble.color);
				return (
					<div
						key={index}
						className={`${colors.bg} ${colors.border} border rounded-xl p-4 transition-all hover:scale-105 hover:shadow-md`}
					>
						<div className="flex items-start gap-3">
							<span className="text-3xl">{bubble.icon}</span>
							<div className="flex-1 min-w-0">
								<p className="text-xs font-medium text-zinc-500 dark:text-zinc-400 uppercase tracking-wide">
									{bubble.title}
								</p>
								<p className={`text-xl font-bold ${colors.text} mt-1 truncate`}>
									{bubble.value}
								</p>
								<p className="text-sm text-zinc-600 dark:text-zinc-400 mt-1">
									{bubble.description}
								</p>
							</div>
						</div>
					</div>
				);
			})}
		</div>
	);
}
