import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Search, FileText, Sparkles } from "lucide-react";
import { generateDemandAnalysis } from "@/lib/analysisService";
import { DataBubbles } from "@/components/DataBubbles";
import { parseDemandAnalysis } from "@/lib/analysisParser";
import { useProduct } from "@/contexts/ProductContext";

export function DemandAnalysis() {
	const { selectedProduct } = useProduct();
	const [productKeyword, setProductKeyword] = useState("");
	const [isAnalyzing, setIsAnalyzing] = useState(false);
	const [showFullAnalysis, setShowFullAnalysis] = useState(false);

	// Auto-fill product name from context
	useEffect(() => {
		if (selectedProduct?.productName) {
			setProductKeyword(selectedProduct.productName);
		}
	}, [selectedProduct]);
	const [results, setResults] = useState<{
		searchVolume: string;
		seasonalPatterns: string;
		marketSize: string;
		rawResponse: string;
	} | null>(null);

	const handleAnalyze = async () => {
		if (!productKeyword.trim()) return;

		setIsAnalyzing(true);
		setResults(null);
		setShowFullAnalysis(false);

		try {
			// Use unified analysis service (automatically switches between mock/AI)
			const content = await generateDemandAnalysis(productKeyword);

			setResults({
				searchVolume: extractSection(content, "search volume"),
				seasonalPatterns: extractSection(content, "seasonal"),
				marketSize: extractSection(content, "market size"),
				rawResponse: content,
			});
		} catch (error) {
			console.error("Demand analysis error:", error);
			setResults({
				searchVolume: "Error fetching data",
				seasonalPatterns: "Error fetching data",
				marketSize: "Error fetching data",
				rawResponse: error instanceof Error ? error.message : "Unknown error",
			});
		} finally {
			setIsAnalyzing(false);
		}
	};

	const extractSection = (text: string, keyword: string): string => {
		const lines = text.split("\n");
		const relevantLines = lines.filter(line =>
			line.toLowerCase().includes(keyword.toLowerCase())
		);
		return relevantLines.join(" ") || "Data not available";
	};

	const dataBubbles = results ? parseDemandAnalysis(results.rawResponse) : [];

	return (
		<Card>
			<CardHeader>
				<CardTitle>Demand Analysis</CardTitle>
				<CardDescription>
					Analyze search volume trends, seasonal patterns, and market size
				</CardDescription>
			</CardHeader>
			<CardContent className="space-y-6">
				<div className="flex gap-4">
					<div className="flex-1 space-y-2">
						<Label htmlFor="product-keyword">Product Keywords or URL</Label>
						<Input
							id="product-keyword"
							placeholder="e.g., wireless earbuds, fitness tracker"
							value={productKeyword}
							onChange={(e) => setProductKeyword(e.target.value)}
							onKeyDown={(e) => e.key === "Enter" && handleAnalyze()}
						/>
					</div>
					<div className="flex items-end">
						<Button onClick={handleAnalyze} disabled={isAnalyzing || !productKeyword.trim()}>
							{isAnalyzing ? (
								<>
									<Loader2 className="size-4 mr-2 animate-spin" />
									Analyzing...
								</>
							) : (
								<>
									<Search className="size-4 mr-2" />
									Analyze
								</>
							)}
						</Button>
					</div>
				</div>

				{results && (
					<div className="space-y-6 border-t pt-6">
						{/* Simplified Data Bubbles */}
						<div className="space-y-4">
							<div className="flex items-center justify-between">
								<div className="flex items-center gap-2">
									<Sparkles className="size-5 text-blue-600 dark:text-blue-400" />
									<h3 className="text-lg font-semibold">Key Insights</h3>
									<Badge variant="secondary" className="text-xs">Simplified View</Badge>
								</div>
								<Button
									variant="outline"
									size="sm"
									onClick={() => setShowFullAnalysis(!showFullAnalysis)}
								>
									<FileText className="size-4 mr-2" />
									{showFullAnalysis ? "Hide" : "Show"} Full Analysis
								</Button>
							</div>

							{dataBubbles.length > 0 ? (
								<DataBubbles bubbles={dataBubbles} />
							) : (
								<p className="text-sm text-zinc-500 dark:text-zinc-400 italic">
									No simplified data available. Click "Show Full Analysis" for details.
								</p>
							)}
						</div>

						{/* Full Professional Analysis (Collapsible) */}
						{showFullAnalysis && (
							<div className="space-y-4 border-t pt-6">
								<div className="flex items-center gap-2">
									<FileText className="size-5 text-zinc-600 dark:text-zinc-400" />
									<h3 className="text-lg font-semibold">Professional Analysis</h3>
									<Badge className="text-xs">In-Depth Report</Badge>
								</div>

								<div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-6 space-y-4">
									<div className="prose dark:prose-invert max-w-none">
										<div className="whitespace-pre-wrap text-sm leading-relaxed">
											{results.rawResponse}
										</div>
									</div>
								</div>

								<div className="grid grid-cols-1 gap-4">
									<div className="border rounded-lg p-4">
										<Badge className="mb-2">Search Volume Insights</Badge>
										<p className="text-sm text-zinc-600 dark:text-zinc-400">
											{results.searchVolume}
										</p>
									</div>

									<div className="border rounded-lg p-4">
										<Badge className="mb-2">Seasonal Patterns</Badge>
										<p className="text-sm text-zinc-600 dark:text-zinc-400">
											{results.seasonalPatterns}
										</p>
									</div>

									<div className="border rounded-lg p-4">
										<Badge className="mb-2">Market Size</Badge>
										<p className="text-sm text-zinc-600 dark:text-zinc-400">
											{results.marketSize}
										</p>
									</div>
								</div>
							</div>
						)}
					</div>
				)}
			</CardContent>
		</Card>
	);
}
