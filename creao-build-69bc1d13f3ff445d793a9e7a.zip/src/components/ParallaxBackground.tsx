import { useEffect, useRef } from "react";

export function ParallaxBackground() {
	const bgRef = useRef<HTMLDivElement>(null);
	const layer1Ref = useRef<HTMLDivElement>(null);
	const layer2Ref = useRef<HTMLDivElement>(null);
	const layer3Ref = useRef<HTMLDivElement>(null);

	useEffect(() => {
		let ticking = false;

		const handleScroll = () => {
			if (!ticking) {
				window.requestAnimationFrame(() => {
					if (!bgRef.current || !layer1Ref.current || !layer2Ref.current || !layer3Ref.current) return;

					// Get scroll position
					const scrollY = window.scrollY;

					// Multiple layers with different speeds for depth
					// Higher speed = moves faster = appears closer
					bgRef.current.style.transform = `translateY(${scrollY * 0.3}px)`;
					layer1Ref.current.style.transform = `translateY(${scrollY * 0.4}px)`;
					layer2Ref.current.style.transform = `translateY(${scrollY * 0.5}px)`;
					layer3Ref.current.style.transform = `translateY(${scrollY * 0.6}px)`;

					ticking = false;
				});

				ticking = true;
			}
		};

		// Add scroll listener with passive for better performance
		window.addEventListener("scroll", handleScroll, { passive: true });

		// Cleanup
		return () => {
			window.removeEventListener("scroll", handleScroll);
		};
	}, []);

	return (
		<>
			{/* Base background layer - moves slowest */}
			<div
				ref={bgRef}
				className="fixed inset-0 -z-10 pointer-events-none will-change-transform"
				style={{
					background: "linear-gradient(135deg, #e0e7ff 0%, #dbeafe 50%, #e0f2fe 100%)",
					height: "120vh", // Extend beyond viewport for parallax
				}}
			/>

			{/* Layer 1 - Subtle gradient orbs */}
			<div
				ref={layer1Ref}
				className="fixed inset-0 -z-10 pointer-events-none will-change-transform opacity-20"
				style={{
					height: "120vh",
					background: `
						radial-gradient(ellipse at 10% 20%, rgba(59, 130, 246, 0.15) 0%, transparent 40%),
						radial-gradient(ellipse at 90% 70%, rgba(139, 92, 246, 0.15) 0%, transparent 40%)
					`,
				}}
			/>

			{/* Layer 2 - Floating shapes */}
			<div
				ref={layer2Ref}
				className="fixed inset-0 -z-10 pointer-events-none will-change-transform opacity-10"
				style={{
					height: "120vh",
					background: `
						radial-gradient(circle at 30% 40%, rgba(16, 185, 129, 0.1) 0%, transparent 30%),
						radial-gradient(circle at 70% 60%, rgba(245, 158, 11, 0.1) 0%, transparent 30%),
						radial-gradient(circle at 50% 80%, rgba(239, 68, 68, 0.1) 0%, transparent 30%)
					`,
				}}
			/>

			{/* Layer 3 - Subtle pattern (moves fastest) */}
			<div
				ref={layer3Ref}
				className="fixed inset-0 -z-10 pointer-events-none will-change-transform opacity-5"
				style={{
					height: "120vh",
					backgroundImage: `
						repeating-linear-gradient(
							45deg,
							transparent,
							transparent 50px,
							rgba(59, 130, 246, 0.03) 50px,
							rgba(59, 130, 246, 0.03) 100px
						),
						repeating-linear-gradient(
							-45deg,
							transparent,
							transparent 50px,
							rgba(139, 92, 246, 0.03) 50px,
							rgba(139, 92, 246, 0.03) 100px
						)
					`,
				}}
			/>
		</>
	);
}
