import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useApiMode } from "@/lib/apiMode";
import { Sparkles, Wifi } from "lucide-react";

export function ApiModeToggle() {
	const { useMockData, toggleMockMode } = useApiMode();

	return (
		<div className="flex items-center gap-3 bg-zinc-100 dark:bg-zinc-800 rounded-lg px-4 py-2 border border-zinc-200 dark:border-zinc-700">
			<div className="flex items-center gap-2">
				{useMockData ? (
					<Sparkles className="size-4 text-purple-600 dark:text-purple-400" />
				) : (
					<Wifi className="size-4 text-green-600 dark:text-green-400" />
				)}
				<Label htmlFor="api-mode-toggle" className="cursor-pointer text-sm font-medium">
					Analysis Mode
				</Label>
			</div>

			<div className="flex items-center gap-2">
				<span className="text-xs text-zinc-600 dark:text-zinc-400">
					{useMockData ? "Mock" : "Live"}
				</span>
				<Switch
					id="api-mode-toggle"
					checked={!useMockData}
					onCheckedChange={() => toggleMockMode()}
				/>
				<Badge variant={useMockData ? "secondary" : "default"} className="text-xs">
					{useMockData ? "Testing Mode (No API Required)" : "Live AI Analysis"}
				</Badge>
			</div>
		</div>
	);
}
