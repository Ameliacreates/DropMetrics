/**
 * Google Gemini AI Service
 * Real AI-powered analysis using Google's Gemini API
 * Seamlessly replaces mock functions with production-ready implementations
 */

import type { FeeEstimate } from "./mockAnalysis";

// Gemini API configuration
const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY || "";
const GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent";

interface GeminiResponse {
	candidates: Array<{
		content: {
			parts: Array<{
				text: string;
			}>;
		};
	}>;
}

/**
 * Generic Gemini API call wrapper
 */
async function callGeminiAPI(prompt: string, temperature = 0.7): Promise<string> {
	if (!GEMINI_API_KEY) {
		throw new Error(
			"GEMINI_API_KEY not found. Please add VITE_GEMINI_API_KEY to your .env file"
		);
	}

	try {
		const response = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
			},
			body: JSON.stringify({
				contents: [
					{
						parts: [
							{
								text: prompt,
							},
						],
					},
				],
				generationConfig: {
					temperature,
					topK: 40,
					topP: 0.95,
					maxOutputTokens: 2048,
				},
			}),
		});

		if (!response.ok) {
			const errorText = await response.text();
			throw new Error(`Gemini API error: ${response.status} - ${errorText}`);
		}

		const data: GeminiResponse = await response.json();

		if (!data.candidates || data.candidates.length === 0) {
			throw new Error("No response from Gemini API");
		}

		return data.candidates[0].content.parts[0].text;
	} catch (error) {
		console.error("Gemini API call failed:", error);
		throw error;
	}
}

/**
 * Generate demand analysis using Gemini AI with real market data
 */
export async function generateDemandAnalysisWithAI(productKeyword: string): Promise<string> {
	const prompt = `You are a market research expert analyzing dropshipping products. Provide a comprehensive demand analysis for "${productKeyword}".

Include the following sections:

# Market Demand Analysis for "${productKeyword}"

## Search Volume & Trends
- Estimated monthly search volume based on current market data
- Search trend direction (growing, stable, declining)
- Year-over-year change percentage
- Key search intent indicators

## Seasonal Demand Patterns
- Identify peak selling months
- Low demand periods
- Holiday/seasonal factors
- Event-driven demand spikes

## Market Size Estimate
- Global market size in USD
- US market size specifically
- Expected CAGR (Compound Annual Growth Rate)
- Market maturity stage

## Growth Trajectory
- Overall market direction
- Key growth drivers
- Emerging trends
- E-commerce adoption rates

Provide realistic, data-driven estimates based on current market conditions in 2025. Be specific with numbers and percentages.`;

	return await callGeminiAPI(prompt, 0.3);
}

/**
 * Generate competition evaluation using Gemini AI
 */
export async function generateCompetitionEvaluationWithAI(
	productCategory: string
): Promise<string> {
	const prompt = `You are an e-commerce competitive analyst. Analyze the competition for "${productCategory}" in the dropshipping market.

Provide a detailed report with these sections:

# Competition Evaluation for "${productCategory}"

## Competitor Pricing Analysis
- Minimum, maximum, and average price points
- Price positioning (budget, mid-range, premium)
- Pricing trends and strategies
- Value perception in the market

## Market Saturation Level
- Overall saturation rating (Low, Medium, High, Oversaturated)
- Explanation of saturation factors
- Barrier to entry assessment
- Market opportunity score

## Key Competitors
- List 5-7 major competitors or competitor types
- Market share estimates
- Competitive strengths and weaknesses
- Emerging players to watch

## Competitive Advantage Opportunities
- Unique value proposition ideas
- Differentiation strategies
- Target audience segmentation
- Recommended marketing channels
- Positioning opportunities

## Strategic Recommendations
- Entry strategy based on saturation level
- Risk assessment
- Success factors
- Budget recommendations

Be realistic and data-driven. Consider current 2025 market conditions and e-commerce trends.`;

	return await callGeminiAPI(prompt, 0.3);
}

/**
 * Generate comprehensive business plan using Gemini AI
 */
export async function generateBusinessPlanWithAI(productName: string): Promise<{
	executiveSummary: string;
	marketAnalysis: string;
	financialProjections: string;
	operationalStrategy: string;
}> {
	const prompt = `You are a business consultant specializing in dropshipping. Create a comprehensive business plan for launching a dropshipping business focused on "${productName}".

Generate four detailed sections:

# EXECUTIVE SUMMARY
- Business concept and model
- Value proposition (what makes it unique)
- Target market overview
- Key success factors
- Competitive advantages
- Financial highlights

# MARKET ANALYSIS
- Target customer demographics (age, income, location, behavior)
- Market size and growth potential (with specific numbers)
- Competitive landscape assessment
- Market trends and opportunities (2025 onwards)
- Consumer behavior insights
- Market positioning strategy

# FINANCIAL PROJECTIONS
- Startup costs breakdown (detailed)
- Expected monthly revenue (months 1-12 progression)
- Operating expenses (COGS, marketing, platform fees, etc.)
- Break-even analysis with timeline
- Profit margins (gross and net)
- Cash flow considerations
- Scaling investment requirements

# OPERATIONAL STRATEGY
- Supplier sourcing strategy (where and how)
- Order fulfillment process (step-by-step)
- Quality control measures
- Customer service approach (channels, response times, policies)
- Marketing and customer acquisition channels (specific platforms)
- Scaling strategy (phases and milestones)
- Key performance metrics to track

Make all recommendations realistic, actionable, and based on current 2025 dropshipping best practices. Include specific numbers, timelines, and percentages where applicable.`;

	const fullResponse = await callGeminiAPI(prompt, 0.5);

	// Parse the response into sections
	// Gemini should naturally format with headers, but we'll extract them
	const sections = parseBusinessPlanSections(fullResponse);

	return sections;
}

/**
 * Parse Gemini's business plan response into structured sections
 */
function parseBusinessPlanSections(fullText: string): {
	executiveSummary: string;
	marketAnalysis: string;
	financialProjections: string;
	operationalStrategy: string;
} {
	// Helper to extract content between headers
	const extractSection = (text: string, startMarker: string, endMarker: string): string => {
		const startIndex = text.indexOf(startMarker);
		if (startIndex === -1) return "";

		const contentStart = startIndex + startMarker.length;
		const endIndex = endMarker === "END" ? text.length : text.indexOf(endMarker, contentStart);

		if (endIndex === -1) return text.substring(contentStart).trim();
		return text.substring(contentStart, endIndex).trim();
	};

	return {
		executiveSummary: extractSection(fullText, "# EXECUTIVE SUMMARY", "# MARKET ANALYSIS") ||
			extractSection(fullText, "Executive Summary", "Market Analysis") ||
			fullText.substring(0, fullText.length / 4),
		marketAnalysis: extractSection(fullText, "# MARKET ANALYSIS", "# FINANCIAL PROJECTIONS") ||
			extractSection(fullText, "Market Analysis", "Financial Projections") ||
			fullText.substring(fullText.length / 4, fullText.length / 2),
		financialProjections: extractSection(fullText, "# FINANCIAL PROJECTIONS", "# OPERATIONAL STRATEGY") ||
			extractSection(fullText, "Financial Projections", "Operational Strategy") ||
			fullText.substring(fullText.length / 2, (fullText.length * 3) / 4),
		operationalStrategy: extractSection(fullText, "# OPERATIONAL STRATEGY", "END") ||
			extractSection(fullText, "Operational Strategy", "END") ||
			fullText.substring((fullText.length * 3) / 4),
	};
}

/**
 * AI-powered fee estimation using Gemini
 * Provides market-driven, accurate cost predictions
 */
export async function estimateFeesWithAI(
	sellingPrice: number,
	productName?: string
): Promise<FeeEstimate> {
	const prompt = `You are a dropshipping cost analyst. Estimate accurate fees for a product with these details:
- Selling Price: $${sellingPrice}
${productName ? `- Product Name: ${productName}` : ""}

Analyze and provide:
1. **Shipping Fee**: Realistic US domestic shipping cost based on likely product weight/size for this price point
2. **Platform Fee**: Combined payment processing (Stripe/PayPal ~2.9% + $0.30) and marketplace fees (estimate best platform: Shopify/Amazon/Etsy/eBay based on price)
3. **Customer Acquisition Cost (CAC)**: Estimated cost to acquire one customer through paid ads (Facebook/Instagram/TikTok), considering:
   - Competition level for this product/price
   - Typical conversion rates
   - Ad costs in 2025
4. **Credit Card Processing**: Standard 2.9% rate

For each fee, provide:
- The exact dollar amount (or percentage for credit card)
- A brief explanation of how you calculated it
- Confidence level (high/medium/low)

Format your response as JSON:
{
  "shippingFee": <number>,
  "platformFee": <number>,
  "customerAcquisitionCost": <number>,
  "creditCardFeePercent": 2.9,
  "confidence": "high|medium|low",
  "explanations": {
    "shipping": "<explanation>",
    "platform": "<explanation>",
    "cac": "<explanation>",
    "creditCard": "Standard payment processing fee"
  }
}

Base estimates on current 2025 market rates and be realistic.`;

	try {
		const response = await callGeminiAPI(prompt, 0.3);

		// Try to parse JSON from response
		// Gemini might wrap it in markdown code blocks
		const jsonMatch = response.match(/\{[\s\S]*\}/);
		if (!jsonMatch) {
			throw new Error("Could not extract JSON from Gemini response");
		}

		const parsed = JSON.parse(jsonMatch[0]);

		return {
			shippingFee: parseFloat(parsed.shippingFee) || 5.0,
			platformFee: parseFloat(parsed.platformFee) || sellingPrice * 0.05,
			customerAcquisitionCost: parseFloat(parsed.customerAcquisitionCost) || sellingPrice * 0.25,
			creditCardFeePercent: 2.9,
			confidence: parsed.confidence || "medium",
			explanation: {
				shipping: parsed.explanations?.shipping || "AI-estimated shipping cost",
				platform: parsed.explanations?.platform || "AI-estimated platform fees",
				cac: parsed.explanations?.cac || "AI-estimated customer acquisition cost",
				creditCard: "Standard payment processing fee of 2.9%",
			},
		};
	} catch (error) {
		console.error("Error parsing Gemini fee estimate:", error);

		// Fallback to intelligent defaults if parsing fails
		return createFallbackEstimate(sellingPrice, productName);
	}
}

/**
 * Fallback estimation using intelligent heuristics
 * Used when AI parsing fails
 */
function createFallbackEstimate(sellingPrice: number, productName?: string): FeeEstimate {
	// Weight-based shipping estimate
	let shippingFee = 3.5;
	if (sellingPrice > 50) shippingFee = 8.5;
	else if (sellingPrice > 20) shippingFee = 5.5;

	// Platform fees: payment processing + marketplace
	const paymentProcessing = sellingPrice * 0.029 + 0.3;
	let marketplaceFee = 0;

	if (sellingPrice < 30) marketplaceFee = sellingPrice * 0.065; // Etsy
	else if (sellingPrice < 60) marketplaceFee = 0; // Shopify
	else if (sellingPrice < 100) marketplaceFee = sellingPrice * 0.125; // eBay
	else marketplaceFee = sellingPrice * 0.15; // Amazon

	const platformFee = paymentProcessing + marketplaceFee;

	// CAC based on price point
	let cacRate = 0.25;
	if (sellingPrice < 25) cacRate = 0.35;
	else if (sellingPrice > 75) cacRate = 0.18;

	const customerAcquisitionCost = sellingPrice * cacRate;

	return {
		shippingFee: parseFloat(shippingFee.toFixed(2)),
		platformFee: parseFloat(platformFee.toFixed(2)),
		customerAcquisitionCost: parseFloat(customerAcquisitionCost.toFixed(2)),
		creditCardFeePercent: 2.9,
		confidence: "medium",
		explanation: {
			shipping: `Estimated for product at $${sellingPrice.toFixed(2)} price point`,
			platform: `Payment processing and marketplace fees`,
			cac: `Estimated based on typical ad costs for this price range`,
			creditCard: "Standard payment processing fee",
		},
	};
}

/**
 * Check if Gemini API is available and configured
 */
export function isGeminiConfigured(): boolean {
	return !!GEMINI_API_KEY && GEMINI_API_KEY.length > 0;
}

/**
 * Get Gemini API status information
 */
export function getGeminiStatus(): {
	configured: boolean;
	message: string;
} {
	if (!GEMINI_API_KEY) {
		return {
			configured: false,
			message: "Gemini API key not configured. Add VITE_GEMINI_API_KEY to your .env file.",
		};
	}

	return {
		configured: true,
		message: "Gemini API is configured and ready to use.",
	};
}
