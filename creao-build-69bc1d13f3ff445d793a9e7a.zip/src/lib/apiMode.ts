/**
 * API Mode Manager
 * Allows toggling between mock mode and real API calls
 */

import { create } from "zustand";
import { persist } from "zustand/middleware";

interface ApiModeState {
	useMockData: boolean;
	toggleMockMode: () => void;
	setMockMode: (enabled: boolean) => void;
}

export const useApiMode = create<ApiModeState>()(
	persist(
		(set) => ({
			useMockData: true, // Default to mock mode
			toggleMockMode: () => set((state) => ({ useMockData: !state.useMockData })),
			setMockMode: (enabled: boolean) => set({ useMockData: enabled }),
		}),
		{
			name: "api-mode-storage",
		}
	)
);
