import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Search, FileText, Sparkles } from "lucide-react";
import { generateCompetitionEvaluation } from "@/lib/analysisService";
import { DataBubbles } from "@/components/DataBubbles";
import { parseCompetitionAnalysis } from "@/lib/analysisParser";
import { useProduct } from "@/contexts/ProductContext";

export function CompetitionEvaluation() {
	const { selectedProduct } = useProduct();
	const [productCategory, setProductCategory] = useState("");
	const [isAnalyzing, setIsAnalyzing] = useState(false);
	const [showFullAnalysis, setShowFullAnalysis] = useState(false);

	// Auto-fill product name from context
	useEffect(() => {
		if (selectedProduct?.productName) {
			setProductCategory(selectedProduct.productName);
		}
	}, [selectedProduct]);
	const [results, setResults] = useState<{
		competitorPricing: string;
		saturationLevel: string;
		competitiveAdvantages: string;
		rawResponse: string;
	} | null>(null);

	const handleAnalyze = async () => {
		if (!productCategory.trim()) return;

		setIsAnalyzing(true);
		setResults(null);

		try {
			// Use unified analysis service (automatically switches between mock/AI)
			const content = await generateCompetitionEvaluation(productCategory);

			setResults({
				competitorPricing: extractSection(content, "pricing"),
				saturationLevel: extractSection(content, "saturation"),
				competitiveAdvantages: extractSection(content, "advantage"),
				rawResponse: content,
			});
		} catch (error) {
			console.error("Competition analysis error:", error);
			setResults({
				competitorPricing: "Error fetching data",
				saturationLevel: "Error fetching data",
				competitiveAdvantages: "Error fetching data",
				rawResponse: error instanceof Error ? error.message : "Unknown error",
			});
		} finally {
			setIsAnalyzing(false);
		}
	};

	const extractSection = (text: string, keyword: string): string => {
		const lines = text.split("\n");
		const relevantLines = lines.filter(line =>
			line.toLowerCase().includes(keyword.toLowerCase())
		);
		return relevantLines.join(" ") || "Data not available";
	};

	const dataBubbles = results ? parseCompetitionAnalysis(results.rawResponse) : [];

	return (
		<Card>
			<CardHeader>
				<CardTitle>Competition Evaluation</CardTitle>
				<CardDescription>
					Analyze competitor pricing, market saturation, and competitive advantages
				</CardDescription>
			</CardHeader>
			<CardContent className="space-y-6">
				<div className="flex gap-4">
					<div className="flex-1 space-y-2">
						<Label htmlFor="product-category">Product Category or Niche</Label>
						<Input
							id="product-category"
							placeholder="e.g., phone accessories, home decor"
							value={productCategory}
							onChange={(e) => setProductCategory(e.target.value)}
							onKeyDown={(e) => e.key === "Enter" && handleAnalyze()}
						/>
					</div>
					<div className="flex items-end">
						<Button onClick={handleAnalyze} disabled={isAnalyzing || !productCategory.trim()}>
							{isAnalyzing ? (
								<>
									<Loader2 className="size-4 mr-2 animate-spin" />
									Analyzing...
								</>
							) : (
								<>
									<Search className="size-4 mr-2" />
									Analyze
								</>
							)}
						</Button>
					</div>
				</div>

				{results && (
					<div className="space-y-6 border-t pt-6">
						{/* Simplified Data Bubbles */}
						<div className="space-y-4">
							<div className="flex items-center justify-between">
								<div className="flex items-center gap-2">
									<Sparkles className="size-5 text-purple-600 dark:text-purple-400" />
									<h3 className="text-lg font-semibold">Key Insights</h3>
									<Badge variant="secondary" className="text-xs">Simplified View</Badge>
								</div>
								<Button
									variant="outline"
									size="sm"
									onClick={() => setShowFullAnalysis(!showFullAnalysis)}
								>
									<FileText className="size-4 mr-2" />
									{showFullAnalysis ? "Hide" : "Show"} Full Analysis
								</Button>
							</div>

							{dataBubbles.length > 0 ? (
								<DataBubbles bubbles={dataBubbles} />
							) : (
								<p className="text-sm text-zinc-500 dark:text-zinc-400 italic">
									No simplified data available. Click "Show Full Analysis" for details.
								</p>
							)}
						</div>

						{/* Full Professional Analysis (Collapsible) */}
						{showFullAnalysis && (
							<div className="space-y-4 border-t pt-6">
								<div className="flex items-center gap-2">
									<FileText className="size-5 text-zinc-600 dark:text-zinc-400" />
									<h3 className="text-lg font-semibold">Professional Analysis</h3>
									<Badge className="text-xs">In-Depth Report</Badge>
								</div>

								<div className="bg-zinc-50 dark:bg-zinc-900 rounded-lg p-6 space-y-4">
									<div className="prose dark:prose-invert max-w-none">
										<div className="whitespace-pre-wrap text-sm leading-relaxed">
											{results.rawResponse}
										</div>
									</div>
								</div>

								<div className="grid grid-cols-1 gap-4">
									<div className="border rounded-lg p-4">
										<Badge className="mb-2">Competitor Pricing</Badge>
										<p className="text-sm text-zinc-600 dark:text-zinc-400">
											{results.competitorPricing}
										</p>
									</div>

									<div className="border rounded-lg p-4">
										<Badge className="mb-2">Market Saturation</Badge>
										<p className="text-sm text-zinc-600 dark:text-zinc-400">
											{results.saturationLevel}
										</p>
									</div>

									<div className="border rounded-lg p-4">
										<Badge className="mb-2">Competitive Advantages</Badge>
										<p className="text-sm text-zinc-600 dark:text-zinc-400">
											{results.competitiveAdvantages}
										</p>
									</div>
								</div>
							</div>
						)}
					</div>
				)}
			</CardContent>
		</Card>
	);
}
