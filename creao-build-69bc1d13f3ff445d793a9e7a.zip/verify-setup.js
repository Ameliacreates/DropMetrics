#!/usr/bin/env node

/**
 * Dropmetrics Setup Verification Script
 *
 * Run this to verify your environment is configured correctly
 * Usage: node verify-setup.js
 */

const fs = require('fs');
const path = require('path');

console.log('\n🔍 Dropmetrics Setup Verification\n');
console.log('================================\n');

let allGood = true;

// Check 1: .env file exists
console.log('📄 Checking .env file...');
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  console.log('   ✅ .env file found');

  // Check if it has the API key
  const envContent = fs.readFileSync(envPath, 'utf8');
  if (envContent.includes('VITE_GEMINI_API_KEY=') && !envContent.includes('your_gemini_api_key_here')) {
    const keyLine = envContent.split('\n').find(line => line.startsWith('VITE_GEMINI_API_KEY='));
    const hasKey = keyLine && keyLine.split('=')[1].trim().length > 10;
    if (hasKey) {
      console.log('   ✅ API key configured (starts with AIza...)');
    } else {
      console.log('   ⚠️  API key appears empty or invalid');
      console.log('      → Add your Google Gemini API key to .env');
      console.log('      → See API_SETUP_GUIDE.md for instructions');
      allGood = false;
    }
  } else {
    console.log('   ⚠️  API key not found in .env');
    console.log('      → Add VITE_GEMINI_API_KEY=your_key to .env');
    allGood = false;
  }
} else {
  console.log('   ⚠️  .env file not found');
  console.log('      → Copy .env.example to .env');
  console.log('      → Add your API key');
  allGood = false;
}
console.log('');

// Check 2: .gitignore includes .env
console.log('🔐 Checking .gitignore...');
const gitignorePath = path.join(__dirname, '.gitignore');
if (fs.existsSync(gitignorePath)) {
  const gitignoreContent = fs.readFileSync(gitignorePath, 'utf8');
  if (gitignoreContent.includes('.env')) {
    console.log('   ✅ .env is in .gitignore (API key will not be committed)');
  } else {
    console.log('   ⚠️  .env not found in .gitignore');
    console.log('      → Add .env to .gitignore to protect your API key');
    allGood = false;
  }
} else {
  console.log('   ⚠️  .gitignore not found');
  console.log('      → Create .gitignore and add .env');
  allGood = false;
}
console.log('');

// Check 3: node_modules exists
console.log('📦 Checking dependencies...');
const nodeModulesPath = path.join(__dirname, 'node_modules');
if (fs.existsSync(nodeModulesPath)) {
  console.log('   ✅ Dependencies installed');
} else {
  console.log('   ⚠️  Dependencies not installed');
  console.log('      → Run: npm install');
  allGood = false;
}
console.log('');

// Check 4: Required files exist
console.log('📁 Checking project files...');
const requiredFiles = [
  'package.json',
  'vite.config.ts',
  'tsconfig.json',
  'src/main.tsx',
  'src/routes/index.tsx',
];

requiredFiles.forEach(file => {
  const filePath = path.join(__dirname, file);
  if (fs.existsSync(filePath)) {
    console.log(`   ✅ ${file}`);
  } else {
    console.log(`   ❌ ${file} missing`);
    allGood = false;
  }
});
console.log('');

// Check 5: Documentation
console.log('📚 Checking documentation...');
const docs = [
  'START_HERE.md',
  'API_SETUP_GUIDE.md',
  'DEPLOYMENT_CHECKLIST.md',
  'QUICK_START.md',
];

docs.forEach(doc => {
  const docPath = path.join(__dirname, doc);
  if (fs.existsSync(docPath)) {
    console.log(`   ✅ ${doc}`);
  } else {
    console.log(`   ⚠️  ${doc} not found`);
  }
});
console.log('');

// Final Summary
console.log('================================\n');
if (allGood) {
  console.log('✅ Your setup looks good!\n');
  console.log('Next steps:');
  console.log('1. Run: npm run dev');
  console.log('2. Open: http://localhost:5173');
  console.log('3. Toggle API mode to test real data\n');
  console.log('For deployment, see: DEPLOYMENT_CHECKLIST.md\n');
} else {
  console.log('⚠️  Some issues found. Please fix them above.\n');
  console.log('For help, see: START_HERE.md\n');
  process.exit(1);
}
