/**
 * localStorage-based database for offline / unauthenticated use.
 *
 * Mirrors the shape of ProductAnalysisModel so the rest of the codebase
 * can call these helpers the same way it calls the remote ORM.
 */

import {
	type ProductAnalysisModel,
	ProductAnalysisSaturationLevel,
} from "@/sdk/database/orm/orm_product_analysis";

const KEY = "dropmetrics_products";

function now(): string {
	return Math.floor(Date.now() / 1000).toString();
}

function generateId(): string {
	return `local_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

function readAll(): ProductAnalysisModel[] {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return [];
		return JSON.parse(raw) as ProductAnalysisModel[];
	} catch {
		return [];
	}
}

function writeAll(records: ProductAnalysisModel[]): void {
	localStorage.setItem(KEY, JSON.stringify(records));
}

export const localDB = {
	insert(data: ProductAnalysisModel[]): ProductAnalysisModel[] {
		const existing = readAll();
		const inserted = data.map((item) => ({
			...item,
			id: item.id || generateId(),
			data_creator: item.data_creator || "local",
			data_updater: item.data_updater || "local",
			create_time: item.create_time || now(),
			update_time: item.update_time || now(),
			saturation_level:
				item.saturation_level ?? ProductAnalysisSaturationLevel.Unspecified,
		}));
		writeAll([...existing, ...inserted]);
		return inserted;
	},

	getAll(): ProductAnalysisModel[] {
		return readAll();
	},

	getByUserId(userId: string): ProductAnalysisModel[] {
		return readAll().filter((r) => r.user_id === userId);
	},

	deleteById(id: string): void {
		writeAll(readAll().filter((r) => r.id !== id));
	},

	clear(): void {
		localStorage.removeItem(KEY);
	},
};
