/**
 * Secure API Configuration
 *
 * This module safely loads API keys from environment variables.
 * The API key is only exposed to the client-side code and is NOT included in the build.
 *
 * SECURITY BEST PRACTICES:
 * 1. API keys are stored in .env (which is gitignored)
 * 2. Keys are loaded at runtime from environment variables
 * 3. For production deployment, use Vercel/Netlify environment variables
 * 4. Never hardcode API keys in source code
 */

interface ApiConfig {
	perplexityApiKey: string | undefined;
	perplexityModel: string;
	isConfigured: boolean;
}

function getApiConfig(): ApiConfig {
	const apiKey = import.meta.env.VITE_PERPLEXITY_API_KEY;
	const model = import.meta.env.VITE_PERPLEXITY_MODEL || "sonar-pro";

	return {
		perplexityApiKey: apiKey,
		perplexityModel: model,
		isConfigured: Boolean(apiKey && apiKey !== "your_api_key_here" && apiKey !== ""),
	};
}

export const apiConfig = getApiConfig();

/**
 * Check if the app is properly configured with API keys
 */
export function isApiConfigured(): boolean {
	return apiConfig.isConfigured;
}

/**
 * Get a user-friendly message about API configuration status
 */
export function getApiStatusMessage(): string {
	if (apiConfig.isConfigured) {
		return "✓ API configured - Real data mode enabled";
	}
	return "⚠ No API key configured - Using mock data mode";
}
